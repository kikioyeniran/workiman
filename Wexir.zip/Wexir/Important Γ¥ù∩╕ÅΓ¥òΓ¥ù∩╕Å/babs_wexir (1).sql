-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 12, 2021 at 08:29 PM
-- Server version: 5.7.30-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `babs_wexir`
--

-- --------------------------------------------------------

--
-- Table structure for table `addons`
--

CREATE TABLE `addons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addons`
--

INSERT INTO `addons` (`id`, `title`, `description`, `amount`, `created_at`, `updated_at`) VALUES
(1, 'Top Rated', 'Make your project flash amongst other projects to freelancers', 5, '2020-12-27 11:29:40', '2021-04-27 12:29:24'),
(2, 'Urgent', 'Motivate freelancers to complete your project in a short period', 5, '2020-12-27 11:33:56', '2021-04-27 12:30:38'),
(3, 'Secured Payment', 'Ensure freelancers of payment after completion.', 5, '2021-04-27 12:31:30', '2021-04-27 12:31:30');

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

CREATE TABLE `banks` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banks`
--

INSERT INTO `banks` (`id`, `code`, `name`, `created_at`, `updated_at`) VALUES
(1, '044', 'ACCESS BANK', '2018-03-08 22:42:52', '2018-03-08 22:42:52'),
(11, '323', 'ACCESSMOBILE', '2018-03-08 22:42:52', '2018-03-08 22:42:52'),
(21, '401', 'ASO SAVINGS AND LOANS', '2018-03-08 22:42:52', '2018-03-08 22:42:52'),
(31, '317', 'CELLULANT', '2018-03-08 22:42:53', '2018-03-08 22:42:53'),
(41, '001', 'CENTRAL BANK OF NIGERIA', '2018-03-08 22:42:54', '2018-03-08 22:42:54'),
(51, '023', 'CITIBANK', '2018-03-08 22:42:54', '2018-03-08 22:42:54'),
(61, '559', 'CORONATION MERCHANT BANK', '2018-03-08 22:42:54', '2018-03-08 22:42:54'),
(71, '310', 'CORPORETTI', '2018-03-08 22:42:55', '2018-03-08 22:42:55'),
(81, '551', 'COVENANT MICROFINANCE BANK', '2018-03-08 22:42:55', '2018-03-08 22:42:55'),
(91, '063', 'DIAMOND BANK', '2018-03-08 22:42:56', '2018-03-08 22:42:56'),
(101, '302', 'EARTHOLEUM (QIK QIK)', '2018-03-08 22:42:56', '2018-03-08 22:42:56'),
(111, '050', 'ECOBANK NIGERIA', '2018-03-08 22:42:56', '2018-03-08 22:42:56'),
(121, '307', 'ECOMOBILE', '2018-03-08 22:42:57', '2018-03-08 22:42:57'),
(131, '562', 'EKONDO MICROFINANCE BANK', '2018-03-08 22:42:57', '2018-03-08 22:42:57'),
(141, '084', 'ENTERPRISE BANK', '2018-03-08 22:42:58', '2018-03-08 22:42:58'),
(151, '040', 'EQUITORIAL TRUST BANK', '2018-03-08 22:42:58', '2018-03-08 22:42:58'),
(161, '306', 'E-TRANZACT', '2018-03-08 22:42:58', '2018-03-08 22:42:58'),
(171, '309', 'FBN M-MONEY', '2018-03-08 22:42:59', '2018-03-08 22:42:59'),
(181, '413', 'FBN MORTGAGES', '2018-03-08 22:42:59', '2018-03-08 22:42:59'),
(191, '314', 'FETS (MY WALLET)', '2018-03-08 22:43:00', '2018-03-08 22:43:00'),
(201, '070', 'FIDELITY BANK', '2018-03-08 22:43:00', '2018-03-08 22:43:00'),
(211, '318', 'FIDELITY MOBILE', '2018-03-08 22:43:01', '2018-03-08 22:43:01'),
(221, '608', 'FINATRUST MICROFINANCE BANK', '2018-03-08 22:43:01', '2018-03-08 22:43:01'),
(231, '011', 'FIRST BANK OF NIGERIA', '2018-03-08 22:43:01', '2018-03-08 22:43:01'),
(241, '214', 'FIRST CITY MONUMENT BANK', '2018-03-08 22:43:02', '2018-03-08 22:43:02'),
(251, '085', 'FIRST INLAND BANK', '2018-03-08 22:43:02', '2018-03-08 22:43:02'),
(261, '501', 'FORTIS MICROFINANCE BANK', '2018-03-08 22:43:02', '2018-03-08 22:43:02'),
(271, '308', 'FORTIS MOBILE', '2018-03-08 22:43:03', '2018-03-08 22:43:03'),
(281, '601', 'FSDH', '2018-03-08 22:43:03', '2018-03-08 22:43:03'),
(291, '315', 'GT MOBILE MONEY', '2018-03-08 22:43:04', '2018-03-08 22:43:04'),
(301, '058', 'GUARANTY TRUST BANK', '2018-03-08 22:43:04', '2018-03-08 22:43:04'),
(311, '324', 'HEDONMARK', '2018-03-08 22:43:04', '2018-03-08 22:43:04'),
(321, '030', 'HERITAGE BANK', '2018-03-08 22:43:05', '2018-03-08 22:43:05'),
(331, '415', 'IMPERIAL HOMES MORTGAGE BANK', '2018-03-08 22:43:05', '2018-03-08 22:43:05'),
(341, '069', 'INTERCONTINENTAL BANK', '2018-03-08 22:43:05', '2018-03-08 22:43:05'),
(351, '301', 'JAIZ BANK', '2018-03-08 22:43:06', '2018-03-08 22:43:06'),
(361, '402', 'JUBILEE LIFE', '2018-03-08 22:43:06', '2018-03-08 22:43:06'),
(371, '303', 'KEGOW', '2018-03-08 22:43:07', '2018-03-08 22:43:07'),
(381, '082', 'KEYSTONE BANK', '2018-03-08 22:43:07', '2018-03-08 22:43:07'),
(391, '014', 'MAINSTREET BANK', '2018-03-08 22:43:08', '2018-03-08 22:43:08'),
(401, '330', 'MIMONEY (POWERED BY INTELLIFIN)', '2018-03-08 22:43:08', '2018-03-08 22:43:08'),
(411, '313', 'M-KUDI', '2018-03-08 22:43:09', '2018-03-08 22:43:09'),
(421, '312', 'MONETIZE', '2018-03-08 22:43:10', '2018-03-08 22:43:10'),
(431, '325', 'MONEYBOX', '2018-03-08 22:43:10', '2018-03-08 22:43:10'),
(441, '561', 'NEW PRUDENTIAL BANK', '2018-03-08 22:43:10', '2018-03-08 22:43:10'),
(451, '552', 'NPF MFB', '2018-03-08 22:43:11', '2018-03-08 22:43:11'),
(461, '056', 'OCEANIC BANK', '2018-03-08 22:43:11', '2018-03-08 22:43:11'),
(471, '606', 'OMOLUABI SAVINGS AND LOANS', '2018-03-08 22:43:12', '2018-03-08 22:43:12'),
(481, '565', 'ONE FINANCE', '2018-03-08 22:43:12', '2018-03-08 22:43:12'),
(491, '327', 'PAGA', '2018-03-08 22:43:12', '2018-03-08 22:43:12'),
(501, '560', 'PAGE MFBANK', '2018-03-08 22:43:13', '2018-03-08 22:43:13'),
(511, '502', 'PARALLEX', '2018-03-08 22:43:13', '2018-03-08 22:43:13'),
(521, '311', 'PARKWAY (READY CASH)', '2018-03-08 22:43:13', '2018-03-08 22:43:13'),
(531, '329', 'PAYATTITUDE ONLINE', '2018-03-08 22:43:14', '2018-03-08 22:43:14'),
(541, '101', 'PROVIDUS BANK', '2018-03-08 22:43:14', '2018-03-08 22:43:14'),
(551, '403', 'SAFETRUST MORTGAGE BANK', '2018-03-08 22:43:15', '2018-03-08 22:43:15'),
(561, '609', 'SEED CAPITAL MICROFINANCE BANK', '2018-03-08 22:43:15', '2018-03-08 22:43:15'),
(571, '076', 'SKYE BANK', '2018-03-08 22:43:15', '2018-03-08 22:43:15'),
(581, '221', 'STANBIC IBTC BANK', '2018-03-08 22:43:16', '2018-03-08 22:43:16'),
(591, '304', 'STANBIC MOBILE', '2018-03-08 22:43:16', '2018-03-08 22:43:16'),
(601, '068', 'STANDARD CHARTERED BANK', '2018-03-08 22:43:17', '2018-03-08 22:43:17'),
(611, '232', 'STERLING BANK', '2018-03-08 22:43:17', '2018-03-08 22:43:17'),
(621, '326', 'STERLING MOBILE', '2018-03-08 22:43:17', '2018-03-08 22:43:17'),
(631, '100', 'SUNTRUST', '2018-03-08 22:43:18', '2018-03-08 22:43:18'),
(641, '319', 'TEASY MOBILE', '2018-03-08 22:43:18', '2018-03-08 22:43:18'),
(651, '523', 'TRUSTBOND', '2018-03-08 22:43:18', '2018-03-08 22:43:18'),
(661, '316', 'U-MO', '2018-03-08 22:43:19', '2018-03-08 22:43:19'),
(671, '032', 'UNION BANK OF NIGERIA', '2018-03-08 22:43:19', '2018-03-08 22:43:19'),
(681, '033', 'UNITED BANK FOR AFRICA', '2018-03-08 22:43:20', '2018-03-08 22:43:20'),
(691, '215', 'UNITY BANK', '2018-03-08 22:43:20', '2018-03-08 22:43:20'),
(701, '566', 'VFD MICROFINANCE BANK', '2018-03-08 22:43:21', '2018-03-08 22:43:21'),
(711, '328', 'VISUAL ICT', '2018-03-08 22:43:21', '2018-03-08 22:43:21'),
(721, '320', 'VTNETWORK', '2018-03-08 22:43:21', '2018-03-08 22:43:21'),
(731, '035', 'WEMA BANK', '2018-03-08 22:43:22', '2018-03-08 22:43:22'),
(741, '057', 'ZENITH BANK', '2018-03-08 22:43:22', '2018-03-08 22:43:22'),
(751, '322', 'ZENITH MOBILE', '2018-03-08 22:43:22', '2018-03-08 22:43:22');

-- --------------------------------------------------------

--
-- Table structure for table `contests`
--

CREATE TABLE `contests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_category_id` bigint(20) UNSIGNED NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum_designer_level` tinyint(4) NOT NULL DEFAULT '0',
  `budget` double NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dollar',
  `first_place_prize` double NOT NULL,
  `second_place_prize` double DEFAULT NULL,
  `third_place_prize` double DEFAULT NULL,
  `duration` smallint(6) NOT NULL DEFAULT '7',
  `ends_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contests`
--

INSERT INTO `contests` (`id`, `user_id`, `title`, `slug`, `sub_category_id`, `description`, `minimum_designer_level`, `budget`, `currency`, `first_place_prize`, `second_place_prize`, `third_place_prize`, `duration`, `ends_at`, `ended_at`, `created_at`, `updated_at`) VALUES
(14, 5, 'Evangelism Training', 'evangelism-training', 50, 'Bulletin design that looks catchy. It\'s a fast project.', 0, 100, 'dollar', 100, NULL, NULL, 7, '2021-05-11 04:39:55', NULL, '2021-05-04 04:33:59', '2021-05-04 04:39:55'),
(15, 5, 'letterhead design', 'letterhead-design', 37, 'I need a proffesional letterhead design, my logo is attached. please put dummy address and other information for now', 0, 40, 'dollar', 40, NULL, NULL, 7, NULL, NULL, '2021-07-18 14:58:57', '2021-07-18 14:58:57');

-- --------------------------------------------------------

--
-- Table structure for table `contest_addons`
--

CREATE TABLE `contest_addons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contest_id` bigint(20) UNSIGNED NOT NULL,
  `addon_id` bigint(20) UNSIGNED NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contest_addons`
--

INSERT INTO `contest_addons` (`id`, `contest_id`, `addon_id`, `content`, `created_at`, `updated_at`) VALUES
(8, 14, 1, NULL, '2021-05-04 04:33:59', '2021-05-04 04:33:59'),
(9, 14, 2, NULL, '2021-05-04 04:33:59', '2021-05-04 04:33:59'),
(10, 14, 3, NULL, '2021-05-04 04:33:59', '2021-05-04 04:33:59'),
(11, 15, 2, NULL, '2021-07-18 14:58:57', '2021-07-18 14:58:57'),
(12, 15, 3, NULL, '2021-07-18 14:58:57', '2021-07-18 14:58:57');

-- --------------------------------------------------------

--
-- Table structure for table `contest_categories`
--

CREATE TABLE `contest_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'file-code-o',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contest_categories`
--

INSERT INTO `contest_categories` (`id`, `title`, `slug`, `icon`, `created_at`, `updated_at`) VALUES
(7, 'Graphics & creative design', 'graphics-creative-design', 'z2U7P.png', '2021-05-04 03:54:01', '2021-05-04 03:54:01'),
(10, 'User Interface and Mockups', 'user-interface-and-mockups', 'zFV0s.png', '2021-05-04 04:13:46', '2021-05-04 04:13:46'),
(12, '3D modelling', '3d-modelling', '6yslE.png', '2021-05-04 04:20:50', '2021-05-04 04:20:50'),
(13, 'Video editing and animation', 'video-editing-and-animation', 'J7hLy.png', '2021-05-04 04:23:58', '2021-05-04 04:23:58');

-- --------------------------------------------------------

--
-- Table structure for table `contest_files`
--

CREATE TABLE `contest_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contest_id` bigint(20) UNSIGNED NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contest_files`
--

INSERT INTO `contest_files` (`id`, `contest_id`, `content`, `created_at`, `updated_at`) VALUES
(11, 14, 'NrGIBCEsGC.jpg', '2021-05-04 04:34:00', '2021-05-04 04:34:00'),
(12, 15, 'tpaDehcybV.png', '2021-07-18 14:58:57', '2021-07-18 14:58:57');

-- --------------------------------------------------------

--
-- Table structure for table `contest_payments`
--

CREATE TABLE `contest_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contest_id` bigint(20) UNSIGNED NOT NULL,
  `payment_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contest_payments`
--

INSERT INTO `contest_payments` (`id`, `contest_id`, `payment_reference`, `payment_method`, `amount`, `paid`, `created_at`, `updated_at`) VALUES
(11, 14, '225145376', 'paystack', 100, 1, '2021-05-04 04:39:55', '2021-05-04 04:39:55');

-- --------------------------------------------------------

--
-- Table structure for table `contest_submissions`
--

CREATE TABLE `contest_submissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contest_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `position` tinyint(4) DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contest_submission_comments`
--

CREATE TABLE `contest_submission_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contest_submission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` enum('file','text','image') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contest_submission_files`
--

CREATE TABLE `contest_submission_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contest_submission_id` bigint(20) UNSIGNED NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contest_submission_file_comments`
--

CREATE TABLE `contest_submission_file_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `file_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contest_sub_categories`
--

CREATE TABLE `contest_sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_amount` double NOT NULL DEFAULT '0',
  `contest_category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contest_sub_categories`
--

INSERT INTO `contest_sub_categories` (`id`, `title`, `slug`, `base_amount`, `contest_category_id`, `created_at`, `updated_at`) VALUES
(34, 'Logo Design', 'logo-design', 30, 7, '2021-05-04 03:55:10', '2021-05-04 03:55:10'),
(35, 'Branding', 'branding', 50, 7, '2021-05-04 03:55:38', '2021-05-04 03:55:38'),
(36, 'Flyer/Poster Design', 'flyerposter-design', 30, 7, '2021-05-04 03:56:00', '2021-05-04 03:56:00'),
(37, 'Business Card Design and Stationery', 'business-card-design-and-stationery', 25, 7, '2021-05-04 03:56:20', '2021-05-04 03:56:20'),
(38, 'Brochure Design', 'brochure-design', 50, 7, '2021-05-04 03:56:41', '2021-05-04 03:56:41'),
(39, 'Social Media/e-flyer Design', 'social-mediae-flyer-design', 25, 7, '2021-05-04 03:57:02', '2021-05-04 03:57:02'),
(40, 'Web Banner Design', 'web-banner-design', 30, 7, '2021-05-04 03:57:19', '2021-05-04 03:57:19'),
(41, 'Illustration/Info graphic Design', 'illustrationinfo-graphic-design', 25, 7, '2021-05-04 03:57:39', '2021-05-04 03:57:39'),
(42, 'Presentation Design', 'presentation-design', 50, 7, '2021-05-04 03:57:58', '2021-05-04 03:57:58'),
(43, 'Book Cover Design', 'book-cover-design', 30, 7, '2021-05-04 03:58:18', '2021-05-04 03:58:18'),
(44, 'Email design', 'email-design', 20, 7, '2021-05-04 03:58:36', '2021-05-04 03:58:36'),
(45, 'Product Packaging Design', 'product-packaging-design', 70, 7, '2021-05-04 03:58:54', '2021-05-04 03:58:54'),
(46, 'Album art/Podcast Design', 'album-artpodcast-design', 30, 7, '2021-05-04 03:59:14', '2021-05-04 03:59:14'),
(47, 'Photo Editing/Photo retouching Design', 'photo-editingphoto-retouching-design', 20, 7, '2021-05-04 03:59:34', '2021-05-04 03:59:34'),
(48, 'Menu/Catalogue Design', 'menucatalogue-design', 40, 7, '2021-05-04 03:59:56', '2021-05-04 03:59:56'),
(49, 'Signage Design', 'signage-design', 40, 7, '2021-05-04 04:00:13', '2021-05-04 04:00:13'),
(50, 'Email newsletter/Bulletin Design', 'email-newsletterbulletin-design', 40, 10, '2021-05-04 04:15:19', '2021-05-04 04:15:19'),
(51, 'Mobile app', 'mobile-app', 100, 10, '2021-05-04 04:15:47', '2021-05-04 04:15:47'),
(52, 'Website mockup', 'website-mockup', 80, 10, '2021-05-04 04:16:04', '2021-05-04 04:16:04'),
(53, 'Product packaging mockups', 'product-packaging-mockups', 60, 10, '2021-05-04 04:16:21', '2021-05-04 04:16:21'),
(54, '3D modelling designs', '3d-modelling-designs', 120, 12, '2021-05-04 04:21:14', '2021-05-04 04:21:14'),
(55, '3D modelling design and animation', '3d-modelling-design-and-animation', 200, 12, '2021-05-04 04:21:28', '2021-05-04 04:21:28'),
(56, 'White Board/Explainer videos', 'white-boardexplainer-videos', 50, 13, '2021-05-04 04:24:18', '2021-05-04 04:24:18'),
(57, 'Animated ads', 'animated-ads', 100, 13, '2021-05-04 04:24:33', '2021-05-04 04:24:33'),
(58, 'Music lyrics video', 'music-lyrics-video', 200, 13, '2021-05-04 04:24:48', '2021-05-04 04:24:48'),
(59, 'Logo/Intro animation', 'logointro-animation', 40, 13, '2021-05-04 04:25:03', '2021-05-04 04:25:03'),
(60, 'Subtitle/Caption video', 'subtitlecaption-video', 70, 13, '2021-05-04 04:25:19', '2021-05-04 04:25:19'),
(61, 'Product animation', 'product-animation', 70, 13, '2021-05-04 04:25:40', '2021-05-04 04:25:40'),
(62, 'Spokesman live video', 'spokesman-live-video', 100, 13, '2021-05-04 04:25:57', '2021-05-04 04:25:57');

-- --------------------------------------------------------

--
-- Table structure for table `contest_tags`
--

CREATE TABLE `contest_tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contest_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contest_tags`
--

INSERT INTO `contest_tags` (`id`, `contest_id`, `title`, `created_at`, `updated_at`) VALUES
(1, 15, 'letterhead', '2021-07-18 14:58:57', '2021-07-18 14:58:57');

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_1_id` bigint(20) UNSIGNED NOT NULL,
  `user_2_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `conversations`
--

INSERT INTO `conversations` (`id`, `user_1_id`, `user_2_id`, `created_at`, `updated_at`) VALUES
(1, 4, 3, '2021-04-12 10:40:51', '2021-04-12 10:40:51'),
(2, 4, 2, '2021-04-12 10:42:28', '2021-04-12 10:42:28'),
(3, 5, 3, '2021-04-13 06:05:37', '2021-04-13 06:05:37');

-- --------------------------------------------------------

--
-- Table structure for table `conversation_messages`
--

CREATE TABLE `conversation_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `content_type` enum('file','image','text') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `conversation_messages`
--

INSERT INTO `conversation_messages` (`id`, `conversation_id`, `user_id`, `content_type`, `content`, `read`, `created_at`, `updated_at`) VALUES
(1, 1, 4, 'text', 'Hello Femi', 0, '2021-04-12 10:40:51', '2021-04-12 10:40:51'),
(2, 2, 4, 'text', 'Yo guy', 0, '2021-04-12 10:42:28', '2021-04-12 10:42:28'),
(3, 2, 2, 'text', 'Hi', 0, '2021-04-12 10:42:56', '2021-04-12 10:42:56'),
(4, 2, 2, 'text', 'Hello', 0, '2021-04-12 10:45:52', '2021-04-12 10:45:52'),
(5, 3, 5, 'text', 'Hi can  you do it fast', 0, '2021-04-13 06:05:37', '2021-04-13 06:05:37'),
(6, 1, 3, 'text', 'Hi, still testing it', 0, '2021-04-13 06:06:34', '2021-04-13 06:06:34'),
(7, 3, 3, 'text', 'yes sure, within 2days', 0, '2021-04-13 06:07:17', '2021-04-13 06:07:17'),
(8, 3, 5, 'text', 'hi', 0, '2021-04-27 13:01:05', '2021-04-27 13:01:05');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `capital` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `citizenship` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_sub_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_decimals` int(11) DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso_3166_2` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `iso_3166_3` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `region_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sub_region_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `eea` tinyint(1) NOT NULL DEFAULT '0',
  `calling_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `capital`, `citizenship`, `country_code`, `currency`, `currency_code`, `currency_sub_unit`, `currency_symbol`, `currency_decimals`, `full_name`, `iso_3166_2`, `iso_3166_3`, `name`, `region_code`, `sub_region_code`, `eea`, `calling_code`, `flag`) VALUES
(4, 'Kabul', 'Afghan', '004', 'afghani', 'AFN', 'pul', '؋', 2, 'Islamic Republic of Afghanistan', 'AF', 'AFG', 'Afghanistan', '142', '034', 0, '93', 'AF.png'),
(8, 'Tirana', 'Albanian', '008', 'lek', 'ALL', '(qindar (pl. qindarka))', 'Lek', 2, 'Republic of Albania', 'AL', 'ALB', 'Albania', '150', '039', 0, '355', 'AL.png'),
(10, 'Antartica', 'of Antartica', '010', '', '', '', '', 2, 'Antarctica', 'AQ', 'ATA', 'Antarctica', '', '', 0, '672', 'AQ.png'),
(12, 'Algiers', 'Algerian', '012', 'Algerian dinar', 'DZD', 'centime', 'DZD', 2, 'People’s Democratic Republic of Algeria', 'DZ', 'DZA', 'Algeria', '002', '015', 0, '213', 'DZ.png'),
(16, 'Pago Pago', 'American Samoan', '016', 'US dollar', 'USD', 'cent', '$', 2, 'Territory of American', 'AS', 'ASM', 'American Samoa', '009', '061', 0, '1', 'AS.png'),
(20, 'Andorra la Vella', 'Andorran', '020', 'euro', 'EUR', 'cent', '€', 2, 'Principality of Andorra', 'AD', 'AND', 'Andorra', '150', '039', 0, '376', 'AD.png'),
(24, 'Luanda', 'Angolan', '024', 'kwanza', 'AOA', 'cêntimo', 'Kz', 2, 'Republic of Angola', 'AO', 'AGO', 'Angola', '002', '017', 0, '244', 'AO.png'),
(28, 'St John’s', 'of Antigua and Barbuda', '028', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Antigua and Barbuda', 'AG', 'ATG', 'Antigua and Barbuda', '019', '029', 0, '1', 'AG.png'),
(31, 'Baku', 'Azerbaijani', '031', 'Azerbaijani manat', 'AZN', 'kepik (inv.)', 'ман', 2, 'Republic of Azerbaijan', 'AZ', 'AZE', 'Azerbaijan', '142', '145', 0, '994', 'AZ.png'),
(32, 'Buenos Aires', 'Argentinian', '032', 'Argentine peso', 'ARS', 'centavo', '$', 2, 'Argentine Republic', 'AR', 'ARG', 'Argentina', '019', '005', 0, '54', 'AR.png'),
(36, 'Canberra', 'Australian', '036', 'Australian dollar', 'AUD', 'cent', '$', 2, 'Commonwealth of Australia', 'AU', 'AUS', 'Australia', '009', '053', 0, '61', 'AU.png'),
(40, 'Vienna', 'Austrian', '040', 'euro', 'EUR', 'cent', '€', 2, 'Republic of Austria', 'AT', 'AUT', 'Austria', '150', '155', 1, '43', 'AT.png'),
(44, 'Nassau', 'Bahamian', '044', 'Bahamian dollar', 'BSD', 'cent', '$', 2, 'Commonwealth of the Bahamas', 'BS', 'BHS', 'Bahamas', '019', '029', 0, '1', 'BS.png'),
(48, 'Manama', 'Bahraini', '048', 'Bahraini dinar', 'BHD', 'fils (inv.)', 'BHD', 3, 'Kingdom of Bahrain', 'BH', 'BHR', 'Bahrain', '142', '145', 0, '973', 'BH.png'),
(50, 'Dhaka', 'Bangladeshi', '050', 'taka (inv.)', 'BDT', 'poisha (inv.)', 'BDT', 2, 'People’s Republic of Bangladesh', 'BD', 'BGD', 'Bangladesh', '142', '034', 0, '880', 'BD.png'),
(51, 'Yerevan', 'Armenian', '051', 'dram (inv.)', 'AMD', 'luma', 'AMD', 2, 'Republic of Armenia', 'AM', 'ARM', 'Armenia', '142', '145', 0, '374', 'AM.png'),
(52, 'Bridgetown', 'Barbadian', '052', 'Barbados dollar', 'BBD', 'cent', '$', 2, 'Barbados', 'BB', 'BRB', 'Barbados', '019', '029', 0, '1', 'BB.png'),
(56, 'Brussels', 'Belgian', '056', 'euro', 'EUR', 'cent', '€', 2, 'Kingdom of Belgium', 'BE', 'BEL', 'Belgium', '150', '155', 1, '32', 'BE.png'),
(60, 'Hamilton', 'Bermudian', '060', 'Bermuda dollar', 'BMD', 'cent', '$', 2, 'Bermuda', 'BM', 'BMU', 'Bermuda', '019', '021', 0, '1', 'BM.png'),
(64, 'Thimphu', 'Bhutanese', '064', 'ngultrum (inv.)', 'BTN', 'chhetrum (inv.)', 'BTN', 2, 'Kingdom of Bhutan', 'BT', 'BTN', 'Bhutan', '142', '034', 0, '975', 'BT.png'),
(68, 'Sucre (BO1)', 'Bolivian', '068', 'boliviano', 'BOB', 'centavo', '$b', 2, 'Plurinational State of Bolivia', 'BO', 'BOL', 'Bolivia, Plurinational State of', '019', '005', 0, '591', 'BO.png'),
(70, 'Sarajevo', 'of Bosnia and Herzegovina', '070', 'convertible mark', 'BAM', 'fening', 'KM', 2, 'Bosnia and Herzegovina', 'BA', 'BIH', 'Bosnia and Herzegovina', '150', '039', 0, '387', 'BA.png'),
(72, 'Gaborone', 'Botswanan', '072', 'pula (inv.)', 'BWP', 'thebe (inv.)', 'P', 2, 'Republic of Botswana', 'BW', 'BWA', 'Botswana', '002', '018', 0, '267', 'BW.png'),
(74, 'Bouvet island', 'of Bouvet island', '074', '', '', '', 'kr', 2, 'Bouvet Island', 'BV', 'BVT', 'Bouvet Island', '', '', 0, '47', 'BV.png'),
(76, 'Brasilia', 'Brazilian', '076', 'real (pl. reais)', 'BRL', 'centavo', 'R$', 2, 'Federative Republic of Brazil', 'BR', 'BRA', 'Brazil', '019', '005', 0, '55', 'BR.png'),
(84, 'Belmopan', 'Belizean', '084', 'Belize dollar', 'BZD', 'cent', 'BZ$', 2, 'Belize', 'BZ', 'BLZ', 'Belize', '019', '013', 0, '501', 'BZ.png'),
(86, 'Diego Garcia', 'Changosian', '086', 'US dollar', 'USD', 'cent', '$', 2, 'British Indian Ocean Territory', 'IO', 'IOT', 'British Indian Ocean Territory', '', '', 0, '246', 'IO.png'),
(90, 'Honiara', 'Solomon Islander', '090', 'Solomon Islands dollar', 'SBD', 'cent', '$', 2, 'Solomon Islands', 'SB', 'SLB', 'Solomon Islands', '009', '054', 0, '677', 'SB.png'),
(92, 'Road Town', 'British Virgin Islander;', '092', 'US dollar', 'USD', 'cent', '$', 2, 'British Virgin Islands', 'VG', 'VGB', 'Virgin Islands, British', '019', '029', 0, '1', 'VG.png'),
(96, 'Bandar Seri Begawan', 'Bruneian', '096', 'Brunei dollar', 'BND', 'sen (inv.)', '$', 2, 'Brunei Darussalam', 'BN', 'BRN', 'Brunei Darussalam', '142', '035', 0, '673', 'BN.png'),
(100, 'Sofia', 'Bulgarian', '100', 'lev (pl. leva)', 'BGN', 'stotinka', 'лв', 2, 'Republic of Bulgaria', 'BG', 'BGR', 'Bulgaria', '150', '151', 1, '359', 'BG.png'),
(104, 'Yangon', 'Burmese', '104', 'kyat', 'MMK', 'pya', 'K', 2, 'Union of Myanmar/', 'MM', 'MMR', 'Myanmar', '142', '035', 0, '95', 'MM.png'),
(108, 'Bujumbura', 'Burundian', '108', 'Burundi franc', 'BIF', 'centime', 'BIF', 0, 'Republic of Burundi', 'BI', 'BDI', 'Burundi', '002', '014', 0, '257', 'BI.png'),
(112, 'Minsk', 'Belarusian', '112', 'Belarusian rouble', 'BYR', 'kopek', 'p.', 2, 'Republic of Belarus', 'BY', 'BLR', 'Belarus', '150', '151', 0, '375', 'BY.png'),
(116, 'Phnom Penh', 'Cambodian', '116', 'riel', 'KHR', 'sen (inv.)', '៛', 2, 'Kingdom of Cambodia', 'KH', 'KHM', 'Cambodia', '142', '035', 0, '855', 'KH.png'),
(120, 'Yaoundé', 'Cameroonian', '120', 'CFA franc (BEAC)', 'XAF', 'centime', 'FCF', 0, 'Republic of Cameroon', 'CM', 'CMR', 'Cameroon', '002', '017', 0, '237', 'CM.png'),
(124, 'Ottawa', 'Canadian', '124', 'Canadian dollar', 'CAD', 'cent', '$', 2, 'Canada', 'CA', 'CAN', 'Canada', '019', '021', 0, '1', 'CA.png'),
(132, 'Praia', 'Cape Verdean', '132', 'Cape Verde escudo', 'CVE', 'centavo', 'CVE', 2, 'Republic of Cape Verde', 'CV', 'CPV', 'Cape Verde', '002', '011', 0, '238', 'CV.png'),
(136, 'George Town', 'Caymanian', '136', 'Cayman Islands dollar', 'KYD', 'cent', '$', 2, 'Cayman Islands', 'KY', 'CYM', 'Cayman Islands', '019', '029', 0, '1', 'KY.png'),
(140, 'Bangui', 'Central African', '140', 'CFA franc (BEAC)', 'XAF', 'centime', 'CFA', 0, 'Central African Republic', 'CF', 'CAF', 'Central African Republic', '002', '017', 0, '236', 'CF.png'),
(144, 'Colombo', 'Sri Lankan', '144', 'Sri Lankan rupee', 'LKR', 'cent', '₨', 2, 'Democratic Socialist Republic of Sri Lanka', 'LK', 'LKA', 'Sri Lanka', '142', '034', 0, '94', 'LK.png'),
(148, 'N’Djamena', 'Chadian', '148', 'CFA franc (BEAC)', 'XAF', 'centime', 'XAF', 0, 'Republic of Chad', 'TD', 'TCD', 'Chad', '002', '017', 0, '235', 'TD.png'),
(152, 'Santiago', 'Chilean', '152', 'Chilean peso', 'CLP', 'centavo', 'CLP', 0, 'Republic of Chile', 'CL', 'CHL', 'Chile', '019', '005', 0, '56', 'CL.png'),
(156, 'Beijing', 'Chinese', '156', 'renminbi-yuan (inv.)', 'CNY', 'jiao (10)', '¥', 2, 'People’s Republic of China', 'CN', 'CHN', 'China', '142', '030', 0, '86', 'CN.png'),
(158, 'Taipei', 'Taiwanese', '158', 'new Taiwan dollar', 'TWD', 'fen (inv.)', 'NT$', 2, 'Republic of China, Taiwan (TW1)', 'TW', 'TWN', 'Taiwan, Province of China', '142', '030', 0, '886', 'TW.png'),
(162, 'Flying Fish Cove', 'Christmas Islander', '162', 'Australian dollar', 'AUD', 'cent', '$', 2, 'Christmas Island Territory', 'CX', 'CXR', 'Christmas Island', '', '', 0, '61', 'CX.png'),
(166, 'Bantam', 'Cocos Islander', '166', 'Australian dollar', 'AUD', 'cent', '$', 2, 'Territory of Cocos (Keeling) Islands', 'CC', 'CCK', 'Cocos (Keeling) Islands', '', '', 0, '61', 'CC.png'),
(170, 'Santa Fe de Bogotá', 'Colombian', '170', 'Colombian peso', 'COP', 'centavo', '$', 2, 'Republic of Colombia', 'CO', 'COL', 'Colombia', '019', '005', 0, '57', 'CO.png'),
(174, 'Moroni', 'Comorian', '174', 'Comorian franc', 'KMF', '', 'KMF', 0, 'Union of the Comoros', 'KM', 'COM', 'Comoros', '002', '014', 0, '269', 'KM.png'),
(175, 'Mamoudzou', 'Mahorais', '175', 'euro', 'EUR', 'cent', '€', 2, 'Departmental Collectivity of Mayotte', 'YT', 'MYT', 'Mayotte', '002', '014', 0, '262', 'YT.png'),
(178, 'Brazzaville', 'Congolese', '178', 'CFA franc (BEAC)', 'XAF', 'centime', 'FCF', 0, 'Republic of the Congo', 'CG', 'COG', 'Congo', '002', '017', 0, '242', 'CG.png'),
(180, 'Kinshasa', 'Congolese', '180', 'Congolese franc', 'CDF', 'centime', 'CDF', 2, 'Democratic Republic of the Congo', 'CD', 'COD', 'Congo, the Democratic Republic of the', '002', '017', 0, '243', 'CD.png'),
(184, 'Avarua', 'Cook Islander', '184', 'New Zealand dollar', 'NZD', 'cent', '$', 2, 'Cook Islands', 'CK', 'COK', 'Cook Islands', '009', '061', 0, '682', 'CK.png'),
(188, 'San José', 'Costa Rican', '188', 'Costa Rican colón (pl. colones)', 'CRC', 'céntimo', '₡', 2, 'Republic of Costa Rica', 'CR', 'CRI', 'Costa Rica', '019', '013', 0, '506', 'CR.png'),
(191, 'Zagreb', 'Croatian', '191', 'kuna (inv.)', 'HRK', 'lipa (inv.)', 'kn', 2, 'Republic of Croatia', 'HR', 'HRV', 'Croatia', '150', '039', 1, '385', 'HR.png'),
(192, 'Havana', 'Cuban', '192', 'Cuban peso', 'CUP', 'centavo', '₱', 2, 'Republic of Cuba', 'CU', 'CUB', 'Cuba', '019', '029', 0, '53', 'CU.png'),
(196, 'Nicosia', 'Cypriot', '196', 'euro', 'EUR', 'cent', 'CYP', 2, 'Republic of Cyprus', 'CY', 'CYP', 'Cyprus', '142', '145', 1, '357', 'CY.png'),
(203, 'Prague', 'Czech', '203', 'Czech koruna (pl. koruny)', 'CZK', 'halér', 'Kč', 2, 'Czech Republic', 'CZ', 'CZE', 'Czech Republic', '150', '151', 1, '420', 'CZ.png'),
(204, 'Porto Novo (BJ1)', 'Beninese', '204', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Republic of Benin', 'BJ', 'BEN', 'Benin', '002', '011', 0, '229', 'BJ.png'),
(208, 'Copenhagen', 'Danish', '208', 'Danish krone', 'DKK', 'øre (inv.)', 'kr', 2, 'Kingdom of Denmark', 'DK', 'DNK', 'Denmark', '150', '154', 1, '45', 'DK.png'),
(212, 'Roseau', 'Dominican', '212', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Commonwealth of Dominica', 'DM', 'DMA', 'Dominica', '019', '029', 0, '1', 'DM.png'),
(214, 'Santo Domingo', 'Dominican', '214', 'Dominican peso', 'DOP', 'centavo', 'RD$', 2, 'Dominican Republic', 'DO', 'DOM', 'Dominican Republic', '019', '029', 0, '1', 'DO.png'),
(218, 'Quito', 'Ecuadorian', '218', 'US dollar', 'USD', 'cent', '$', 2, 'Republic of Ecuador', 'EC', 'ECU', 'Ecuador', '019', '005', 0, '593', 'EC.png'),
(222, 'San Salvador', 'Salvadoran', '222', 'Salvadorian colón (pl. colones)', 'SVC', 'centavo', '$', 2, 'Republic of El Salvador', 'SV', 'SLV', 'El Salvador', '019', '013', 0, '503', 'SV.png'),
(226, 'Malabo', 'Equatorial Guinean', '226', 'CFA franc (BEAC)', 'XAF', 'centime', 'FCF', 2, 'Republic of Equatorial Guinea', 'GQ', 'GNQ', 'Equatorial Guinea', '002', '017', 0, '240', 'GQ.png'),
(231, 'Addis Ababa', 'Ethiopian', '231', 'birr (inv.)', 'ETB', 'cent', 'ETB', 2, 'Federal Democratic Republic of Ethiopia', 'ET', 'ETH', 'Ethiopia', '002', '014', 0, '251', 'ET.png'),
(232, 'Asmara', 'Eritrean', '232', 'nakfa', 'ERN', 'cent', 'Nfk', 2, 'State of Eritrea', 'ER', 'ERI', 'Eritrea', '002', '014', 0, '291', 'ER.png'),
(233, 'Tallinn', 'Estonian', '233', 'euro', 'EUR', 'cent', 'kr', 2, 'Republic of Estonia', 'EE', 'EST', 'Estonia', '150', '154', 1, '372', 'EE.png'),
(234, 'Tórshavn', 'Faeroese', '234', 'Danish krone', 'DKK', 'øre (inv.)', 'kr', 2, 'Faeroe Islands', 'FO', 'FRO', 'Faroe Islands', '150', '154', 0, '298', 'FO.png'),
(238, 'Stanley', 'Falkland Islander', '238', 'Falkland Islands pound', 'FKP', 'new penny', '£', 2, 'Falkland Islands', 'FK', 'FLK', 'Falkland Islands (Malvinas)', '019', '005', 0, '500', 'FK.png'),
(239, 'King Edward Point (Grytviken)', 'of South Georgia and the South Sandwich Islands', '239', '', '', '', '£', 2, 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', 'South Georgia and the South Sandwich Islands', '', '', 0, '44', 'GS.png'),
(242, 'Suva', 'Fijian', '242', 'Fiji dollar', 'FJD', 'cent', '$', 2, 'Republic of Fiji', 'FJ', 'FJI', 'Fiji', '009', '054', 0, '679', 'FJ.png'),
(246, 'Helsinki', 'Finnish', '246', 'euro', 'EUR', 'cent', '€', 2, 'Republic of Finland', 'FI', 'FIN', 'Finland', '150', '154', 1, '358', 'FI.png'),
(248, 'Mariehamn', 'Åland Islander', '248', 'euro', 'EUR', 'cent', NULL, NULL, 'Åland Islands', 'AX', 'ALA', 'Åland Islands', '150', '154', 0, '358', NULL),
(250, 'Paris', 'French', '250', 'euro', 'EUR', 'cent', '€', 2, 'French Republic', 'FR', 'FRA', 'France', '150', '155', 1, '33', 'FR.png'),
(254, 'Cayenne', 'Guianese', '254', 'euro', 'EUR', 'cent', '€', 2, 'French Guiana', 'GF', 'GUF', 'French Guiana', '019', '005', 0, '594', 'GF.png'),
(258, 'Papeete', 'Polynesian', '258', 'CFP franc', 'XPF', 'centime', 'XPF', 0, 'French Polynesia', 'PF', 'PYF', 'French Polynesia', '009', '061', 0, '689', 'PF.png'),
(260, 'Port-aux-Francais', 'of French Southern and Antarctic Lands', '260', 'euro', 'EUR', 'cent', '€', 2, 'French Southern and Antarctic Lands', 'TF', 'ATF', 'French Southern Territories', '', '', 0, '33', 'TF.png'),
(262, 'Djibouti', 'Djiboutian', '262', 'Djibouti franc', 'DJF', '', 'DJF', 0, 'Republic of Djibouti', 'DJ', 'DJI', 'Djibouti', '002', '014', 0, '253', 'DJ.png'),
(266, 'Libreville', 'Gabonese', '266', 'CFA franc (BEAC)', 'XAF', 'centime', 'FCF', 0, 'Gabonese Republic', 'GA', 'GAB', 'Gabon', '002', '017', 0, '241', 'GA.png'),
(268, 'Tbilisi', 'Georgian', '268', 'lari', 'GEL', 'tetri (inv.)', 'GEL', 2, 'Georgia', 'GE', 'GEO', 'Georgia', '142', '145', 0, '995', 'GE.png'),
(270, 'Banjul', 'Gambian', '270', 'dalasi (inv.)', 'GMD', 'butut', 'D', 2, 'Republic of the Gambia', 'GM', 'GMB', 'Gambia', '002', '011', 0, '220', 'GM.png'),
(275, NULL, 'Palestinian', '275', NULL, NULL, NULL, '₪', 2, NULL, 'PS', 'PSE', 'Palestinian Territory, Occupied', '142', '145', 0, '970', 'PS.png'),
(276, 'Berlin', 'German', '276', 'euro', 'EUR', 'cent', '€', 2, 'Federal Republic of Germany', 'DE', 'DEU', 'Germany', '150', '155', 1, '49', 'DE.png'),
(288, 'Accra', 'Ghanaian', '288', 'Ghana cedi', 'GHS', 'pesewa', '¢', 2, 'Republic of Ghana', 'GH', 'GHA', 'Ghana', '002', '011', 0, '233', 'GH.png'),
(292, 'Gibraltar', 'Gibraltarian', '292', 'Gibraltar pound', 'GIP', 'penny', '£', 2, 'Gibraltar', 'GI', 'GIB', 'Gibraltar', '150', '039', 0, '350', 'GI.png'),
(296, 'Tarawa', 'Kiribatian', '296', 'Australian dollar', 'AUD', 'cent', '$', 2, 'Republic of Kiribati', 'KI', 'KIR', 'Kiribati', '009', '057', 0, '686', 'KI.png'),
(300, 'Athens', 'Greek', '300', 'euro', 'EUR', 'cent', '€', 2, 'Hellenic Republic', 'GR', 'GRC', 'Greece', '150', '039', 1, '30', 'GR.png'),
(304, 'Nuuk', 'Greenlander', '304', 'Danish krone', 'DKK', 'øre (inv.)', 'kr', 2, 'Greenland', 'GL', 'GRL', 'Greenland', '019', '021', 0, '299', 'GL.png'),
(308, 'St George’s', 'Grenadian', '308', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Grenada', 'GD', 'GRD', 'Grenada', '019', '029', 0, '1', 'GD.png'),
(312, 'Basse Terre', 'Guadeloupean', '312', 'euro', 'EUR ', 'cent', '€', 2, 'Guadeloupe', 'GP', 'GLP', 'Guadeloupe', '019', '029', 0, '590', 'GP.png'),
(316, 'Agaña (Hagåtña)', 'Guamanian', '316', 'US dollar', 'USD', 'cent', '$', 2, 'Territory of Guam', 'GU', 'GUM', 'Guam', '009', '057', 0, '1', 'GU.png'),
(320, 'Guatemala City', 'Guatemalan', '320', 'quetzal (pl. quetzales)', 'GTQ', 'centavo', 'Q', 2, 'Republic of Guatemala', 'GT', 'GTM', 'Guatemala', '019', '013', 0, '502', 'GT.png'),
(324, 'Conakry', 'Guinean', '324', 'Guinean franc', 'GNF', '', 'GNF', 0, 'Republic of Guinea', 'GN', 'GIN', 'Guinea', '002', '011', 0, '224', 'GN.png'),
(328, 'Georgetown', 'Guyanese', '328', 'Guyana dollar', 'GYD', 'cent', '$', 2, 'Cooperative Republic of Guyana', 'GY', 'GUY', 'Guyana', '019', '005', 0, '592', 'GY.png'),
(332, 'Port-au-Prince', 'Haitian', '332', 'gourde', 'HTG', 'centime', 'G', 2, 'Republic of Haiti', 'HT', 'HTI', 'Haiti', '019', '029', 0, '509', 'HT.png'),
(334, 'Territory of Heard Island and McDonald Islands', 'of Territory of Heard Island and McDonald Islands', '334', '', '', '', '$', 2, 'Territory of Heard Island and McDonald Islands', 'HM', 'HMD', 'Heard Island and McDonald Islands', '', '', 0, '61', 'HM.png'),
(336, 'Vatican City', 'of the Holy See/of the Vatican', '336', 'euro', 'EUR', 'cent', '€', 2, 'the Holy See/ Vatican City State', 'VA', 'VAT', 'Holy See (Vatican City State)', '150', '039', 0, '39', 'VA.png'),
(340, 'Tegucigalpa', 'Honduran', '340', 'lempira', 'HNL', 'centavo', 'L', 2, 'Republic of Honduras', 'HN', 'HND', 'Honduras', '019', '013', 0, '504', 'HN.png'),
(344, '(HK3)', 'Hong Kong Chinese', '344', 'Hong Kong dollar', 'HKD', 'cent', '$', 2, 'Hong Kong Special Administrative Region of the People’s Republic of China (HK2)', 'HK', 'HKG', 'Hong Kong', '142', '030', 0, '852', 'HK.png'),
(348, 'Budapest', 'Hungarian', '348', 'forint (inv.)', 'HUF', '(fillér (inv.))', 'Ft', 2, 'Republic of Hungary', 'HU', 'HUN', 'Hungary', '150', '151', 1, '36', 'HU.png'),
(352, 'Reykjavik', 'Icelander', '352', 'króna (pl. krónur)', 'ISK', '', 'kr', 0, 'Republic of Iceland', 'IS', 'ISL', 'Iceland', '150', '154', 0, '354', 'IS.png'),
(356, 'New Delhi', 'Indian', '356', 'Indian rupee', 'INR', 'paisa', '₹', 2, 'Republic of India', 'IN', 'IND', 'India', '142', '034', 0, '91', 'IN.png'),
(360, 'Jakarta', 'Indonesian', '360', 'Indonesian rupiah (inv.)', 'IDR', 'sen (inv.)', 'Rp', 2, 'Republic of Indonesia', 'ID', 'IDN', 'Indonesia', '142', '035', 0, '62', 'ID.png'),
(364, 'Tehran', 'Iranian', '364', 'Iranian rial', 'IRR', '(dinar) (IR1)', '﷼', 2, 'Islamic Republic of Iran', 'IR', 'IRN', 'Iran, Islamic Republic of', '142', '034', 0, '98', 'IR.png'),
(368, 'Baghdad', 'Iraqi', '368', 'Iraqi dinar', 'IQD', 'fils (inv.)', 'IQD', 3, 'Republic of Iraq', 'IQ', 'IRQ', 'Iraq', '142', '145', 0, '964', 'IQ.png'),
(372, 'Dublin', 'Irish', '372', 'euro', 'EUR', 'cent', '€', 2, 'Ireland (IE1)', 'IE', 'IRL', 'Ireland', '150', '154', 1, '353', 'IE.png'),
(376, '(IL1)', 'Israeli', '376', 'shekel', 'ILS', 'agora', '₪', 2, 'State of Israel', 'IL', 'ISR', 'Israel', '142', '145', 0, '972', 'IL.png'),
(380, 'Rome', 'Italian', '380', 'euro', 'EUR', 'cent', '€', 2, 'Italian Republic', 'IT', 'ITA', 'Italy', '150', '039', 1, '39', 'IT.png'),
(384, 'Yamoussoukro (CI1)', 'Ivorian', '384', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Republic of Côte d’Ivoire', 'CI', 'CIV', 'Côte d\'Ivoire', '002', '011', 0, '225', 'CI.png'),
(388, 'Kingston', 'Jamaican', '388', 'Jamaica dollar', 'JMD', 'cent', '$', 2, 'Jamaica', 'JM', 'JAM', 'Jamaica', '019', '029', 0, '1', 'JM.png'),
(392, 'Tokyo', 'Japanese', '392', 'yen (inv.)', 'JPY', '(sen (inv.)) (JP1)', '¥', 0, 'Japan', 'JP', 'JPN', 'Japan', '142', '030', 0, '81', 'JP.png'),
(398, 'Astana', 'Kazakh', '398', 'tenge (inv.)', 'KZT', 'tiyn', 'лв', 2, 'Republic of Kazakhstan', 'KZ', 'KAZ', 'Kazakhstan', '142', '143', 0, '7', 'KZ.png'),
(400, 'Amman', 'Jordanian', '400', 'Jordanian dinar', 'JOD', '100 qirsh', 'JOD', 2, 'Hashemite Kingdom of Jordan', 'JO', 'JOR', 'Jordan', '142', '145', 0, '962', 'JO.png'),
(404, 'Nairobi', 'Kenyan', '404', 'Kenyan shilling', 'KES', 'cent', 'KES', 2, 'Republic of Kenya', 'KE', 'KEN', 'Kenya', '002', '014', 0, '254', 'KE.png'),
(408, 'Pyongyang', 'North Korean', '408', 'North Korean won (inv.)', 'KPW', 'chun (inv.)', '₩', 2, 'Democratic People’s Republic of Korea', 'KP', 'PRK', 'Korea, Democratic People\'s Republic of', '142', '030', 0, '850', 'KP.png'),
(410, 'Seoul', 'South Korean', '410', 'South Korean won (inv.)', 'KRW', '(chun (inv.))', '₩', 0, 'Republic of Korea', 'KR', 'KOR', 'Korea, Republic of', '142', '030', 0, '82', 'KR.png'),
(414, 'Kuwait City', 'Kuwaiti', '414', 'Kuwaiti dinar', 'KWD', 'fils (inv.)', 'KWD', 3, 'State of Kuwait', 'KW', 'KWT', 'Kuwait', '142', '145', 0, '965', 'KW.png'),
(417, 'Bishkek', 'Kyrgyz', '417', 'som', 'KGS', 'tyiyn', 'лв', 2, 'Kyrgyz Republic', 'KG', 'KGZ', 'Kyrgyzstan', '142', '143', 0, '996', 'KG.png'),
(418, 'Vientiane', 'Lao', '418', 'kip (inv.)', 'LAK', '(at (inv.))', '₭', 0, 'Lao People’s Democratic Republic', 'LA', 'LAO', 'Lao People\'s Democratic Republic', '142', '035', 0, '856', 'LA.png'),
(422, 'Beirut', 'Lebanese', '422', 'Lebanese pound', 'LBP', '(piastre)', '£', 2, 'Lebanese Republic', 'LB', 'LBN', 'Lebanon', '142', '145', 0, '961', 'LB.png'),
(426, 'Maseru', 'Basotho', '426', 'loti (pl. maloti)', 'LSL', 'sente', 'L', 2, 'Kingdom of Lesotho', 'LS', 'LSO', 'Lesotho', '002', '018', 0, '266', 'LS.png'),
(428, 'Riga', 'Latvian', '428', 'euro', 'EUR', 'cent', 'Ls', 2, 'Republic of Latvia', 'LV', 'LVA', 'Latvia', '150', '154', 1, '371', 'LV.png'),
(430, 'Monrovia', 'Liberian', '430', 'Liberian dollar', 'LRD', 'cent', '$', 2, 'Republic of Liberia', 'LR', 'LBR', 'Liberia', '002', '011', 0, '231', 'LR.png'),
(434, 'Tripoli', 'Libyan', '434', 'Libyan dinar', 'LYD', 'dirham', 'LYD', 3, 'Socialist People’s Libyan Arab Jamahiriya', 'LY', 'LBY', 'Libya', '002', '015', 0, '218', 'LY.png'),
(438, 'Vaduz', 'Liechtensteiner', '438', 'Swiss franc', 'CHF', 'centime', 'CHF', 2, 'Principality of Liechtenstein', 'LI', 'LIE', 'Liechtenstein', '150', '155', 0, '423', 'LI.png'),
(440, 'Vilnius', 'Lithuanian', '440', 'euro', 'EUR', 'cent', 'Lt', 2, 'Republic of Lithuania', 'LT', 'LTU', 'Lithuania', '150', '154', 1, '370', 'LT.png'),
(442, 'Luxembourg', 'Luxembourger', '442', 'euro', 'EUR', 'cent', '€', 2, 'Grand Duchy of Luxembourg', 'LU', 'LUX', 'Luxembourg', '150', '155', 1, '352', 'LU.png'),
(446, 'Macao (MO3)', 'Macanese', '446', 'pataca', 'MOP', 'avo', 'MOP', 2, 'Macao Special Administrative Region of the People’s Republic of China (MO2)', 'MO', 'MAC', 'Macao', '142', '030', 0, '853', 'MO.png'),
(450, 'Antananarivo', 'Malagasy', '450', 'ariary', 'MGA', 'iraimbilanja (inv.)', 'MGA', 2, 'Republic of Madagascar', 'MG', 'MDG', 'Madagascar', '002', '014', 0, '261', 'MG.png'),
(454, 'Lilongwe', 'Malawian', '454', 'Malawian kwacha (inv.)', 'MWK', 'tambala (inv.)', 'MK', 2, 'Republic of Malawi', 'MW', 'MWI', 'Malawi', '002', '014', 0, '265', 'MW.png'),
(458, 'Kuala Lumpur (MY1)', 'Malaysian', '458', 'ringgit (inv.)', 'MYR', 'sen (inv.)', 'RM', 2, 'Malaysia', 'MY', 'MYS', 'Malaysia', '142', '035', 0, '60', 'MY.png'),
(462, 'Malé', 'Maldivian', '462', 'rufiyaa', 'MVR', 'laari (inv.)', 'Rf', 2, 'Republic of Maldives', 'MV', 'MDV', 'Maldives', '142', '034', 0, '960', 'MV.png'),
(466, 'Bamako', 'Malian', '466', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Republic of Mali', 'ML', 'MLI', 'Mali', '002', '011', 0, '223', 'ML.png'),
(470, 'Valletta', 'Maltese', '470', 'euro', 'EUR', 'cent', 'MTL', 2, 'Republic of Malta', 'MT', 'MLT', 'Malta', '150', '039', 1, '356', 'MT.png'),
(474, 'Fort-de-France', 'Martinican', '474', 'euro', 'EUR', 'cent', '€', 2, 'Martinique', 'MQ', 'MTQ', 'Martinique', '019', '029', 0, '596', 'MQ.png'),
(478, 'Nouakchott', 'Mauritanian', '478', 'ouguiya', 'MRO', 'khoum', 'UM', 2, 'Islamic Republic of Mauritania', 'MR', 'MRT', 'Mauritania', '002', '011', 0, '222', 'MR.png'),
(480, 'Port Louis', 'Mauritian', '480', 'Mauritian rupee', 'MUR', 'cent', '₨', 2, 'Republic of Mauritius', 'MU', 'MUS', 'Mauritius', '002', '014', 0, '230', 'MU.png'),
(484, 'Mexico City', 'Mexican', '484', 'Mexican peso', 'MXN', 'centavo', '$', 2, 'United Mexican States', 'MX', 'MEX', 'Mexico', '019', '013', 0, '52', 'MX.png'),
(492, 'Monaco', 'Monegasque', '492', 'euro', 'EUR', 'cent', '€', 2, 'Principality of Monaco', 'MC', 'MCO', 'Monaco', '150', '155', 0, '377', 'MC.png'),
(496, 'Ulan Bator', 'Mongolian', '496', 'tugrik', 'MNT', 'möngö (inv.)', '₮', 2, 'Mongolia', 'MN', 'MNG', 'Mongolia', '142', '030', 0, '976', 'MN.png'),
(498, 'Chisinau', 'Moldovan', '498', 'Moldovan leu (pl. lei)', 'MDL', 'ban', 'MDL', 2, 'Republic of Moldova', 'MD', 'MDA', 'Moldova, Republic of', '150', '151', 0, '373', 'MD.png'),
(499, 'Podgorica', 'Montenegrin', '499', 'euro', 'EUR', 'cent', '€', 2, 'Montenegro', 'ME', 'MNE', 'Montenegro', '150', '039', 0, '382', 'ME.png'),
(500, 'Plymouth (MS2)', 'Montserratian', '500', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Montserrat', 'MS', 'MSR', 'Montserrat', '019', '029', 0, '1', 'MS.png'),
(504, 'Rabat', 'Moroccan', '504', 'Moroccan dirham', 'MAD', 'centime', 'MAD', 2, 'Kingdom of Morocco', 'MA', 'MAR', 'Morocco', '002', '015', 0, '212', 'MA.png'),
(508, 'Maputo', 'Mozambican', '508', 'metical', 'MZN', 'centavo', 'MT', 2, 'Republic of Mozambique', 'MZ', 'MOZ', 'Mozambique', '002', '014', 0, '258', 'MZ.png'),
(512, 'Muscat', 'Omani', '512', 'Omani rial', 'OMR', 'baiza', '﷼', 3, 'Sultanate of Oman', 'OM', 'OMN', 'Oman', '142', '145', 0, '968', 'OM.png'),
(516, 'Windhoek', 'Namibian', '516', 'Namibian dollar', 'NAD', 'cent', '$', 2, 'Republic of Namibia', 'NA', 'NAM', 'Namibia', '002', '018', 0, '264', 'NA.png'),
(520, 'Yaren', 'Nauruan', '520', 'Australian dollar', 'AUD', 'cent', '$', 2, 'Republic of Nauru', 'NR', 'NRU', 'Nauru', '009', '057', 0, '674', 'NR.png'),
(524, 'Kathmandu', 'Nepalese', '524', 'Nepalese rupee', 'NPR', 'paisa (inv.)', '₨', 2, 'Nepal', 'NP', 'NPL', 'Nepal', '142', '034', 0, '977', 'NP.png'),
(528, 'Amsterdam (NL2)', 'Dutch', '528', 'euro', 'EUR', 'cent', '€', 2, 'Kingdom of the Netherlands', 'NL', 'NLD', 'Netherlands', '150', '155', 1, '31', 'NL.png'),
(531, 'Willemstad', 'Curaçaoan', '531', 'Netherlands Antillean guilder (CW1)', 'ANG', 'cent', NULL, NULL, 'Curaçao', 'CW', 'CUW', 'Curaçao', '019', '029', 0, '599', NULL),
(533, 'Oranjestad', 'Aruban', '533', 'Aruban guilder', 'AWG', 'cent', 'ƒ', 2, 'Aruba', 'AW', 'ABW', 'Aruba', '019', '029', 0, '297', 'AW.png'),
(534, 'Philipsburg', 'Sint Maartener', '534', 'Netherlands Antillean guilder (SX1)', 'ANG', 'cent', NULL, NULL, 'Sint Maarten', 'SX', 'SXM', 'Sint Maarten (Dutch part)', '019', '029', 0, '721', NULL),
(535, NULL, 'of Bonaire, Sint Eustatius and Saba', '535', 'US dollar', 'USD', 'cent', NULL, NULL, NULL, 'BQ', 'BES', 'Bonaire, Sint Eustatius and Saba', '019', '029', 0, '599', NULL),
(540, 'Nouméa', 'New Caledonian', '540', 'CFP franc', 'XPF', 'centime', 'XPF', 0, 'New Caledonia', 'NC', 'NCL', 'New Caledonia', '009', '054', 0, '687', 'NC.png'),
(548, 'Port Vila', 'Vanuatuan', '548', 'vatu (inv.)', 'VUV', '', 'Vt', 0, 'Republic of Vanuatu', 'VU', 'VUT', 'Vanuatu', '009', '054', 0, '678', 'VU.png'),
(554, 'Wellington', 'New Zealander', '554', 'New Zealand dollar', 'NZD', 'cent', '$', 2, 'New Zealand', 'NZ', 'NZL', 'New Zealand', '009', '053', 0, '64', 'NZ.png'),
(558, 'Managua', 'Nicaraguan', '558', 'córdoba oro', 'NIO', 'centavo', 'C$', 2, 'Republic of Nicaragua', 'NI', 'NIC', 'Nicaragua', '019', '013', 0, '505', 'NI.png'),
(562, 'Niamey', 'Nigerien', '562', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Republic of Niger', 'NE', 'NER', 'Niger', '002', '011', 0, '227', 'NE.png'),
(566, 'Abuja', 'Nigerian', '566', 'naira (inv.)', 'NGN', 'kobo (inv.)', '₦', 2, 'Federal Republic of Nigeria', 'NG', 'NGA', 'Nigeria', '002', '011', 0, '234', 'NG.png'),
(570, 'Alofi', 'Niuean', '570', 'New Zealand dollar', 'NZD', 'cent', '$', 2, 'Niue', 'NU', 'NIU', 'Niue', '009', '061', 0, '683', 'NU.png'),
(574, 'Kingston', 'Norfolk Islander', '574', 'Australian dollar', 'AUD', 'cent', '$', 2, 'Territory of Norfolk Island', 'NF', 'NFK', 'Norfolk Island', '009', '053', 0, '672', 'NF.png'),
(578, 'Oslo', 'Norwegian', '578', 'Norwegian krone (pl. kroner)', 'NOK', 'øre (inv.)', 'kr', 2, 'Kingdom of Norway', 'NO', 'NOR', 'Norway', '150', '154', 0, '47', 'NO.png'),
(580, 'Saipan', 'Northern Mariana Islander', '580', 'US dollar', 'USD', 'cent', '$', 2, 'Commonwealth of the Northern Mariana Islands', 'MP', 'MNP', 'Northern Mariana Islands', '009', '057', 0, '1', 'MP.png'),
(581, 'United States Minor Outlying Islands', 'of United States Minor Outlying Islands', '581', 'US dollar', 'USD', 'cent', '$', 2, 'United States Minor Outlying Islands', 'UM', 'UMI', 'United States Minor Outlying Islands', '', '', 0, '1', 'UM.png'),
(583, 'Palikir', 'Micronesian', '583', 'US dollar', 'USD', 'cent', '$', 2, 'Federated States of Micronesia', 'FM', 'FSM', 'Micronesia, Federated States of', '009', '057', 0, '691', 'FM.png'),
(584, 'Majuro', 'Marshallese', '584', 'US dollar', 'USD', 'cent', '$', 2, 'Republic of the Marshall Islands', 'MH', 'MHL', 'Marshall Islands', '009', '057', 0, '692', 'MH.png'),
(585, 'Melekeok', 'Palauan', '585', 'US dollar', 'USD', 'cent', '$', 2, 'Republic of Palau', 'PW', 'PLW', 'Palau', '009', '057', 0, '680', 'PW.png'),
(586, 'Islamabad', 'Pakistani', '586', 'Pakistani rupee', 'PKR', 'paisa', '₨', 2, 'Islamic Republic of Pakistan', 'PK', 'PAK', 'Pakistan', '142', '034', 0, '92', 'PK.png'),
(591, 'Panama City', 'Panamanian', '591', 'balboa', 'PAB', 'centésimo', 'B/.', 2, 'Republic of Panama', 'PA', 'PAN', 'Panama', '019', '013', 0, '507', 'PA.png'),
(598, 'Port Moresby', 'Papua New Guinean', '598', 'kina (inv.)', 'PGK', 'toea (inv.)', 'PGK', 2, 'Independent State of Papua New Guinea', 'PG', 'PNG', 'Papua New Guinea', '009', '054', 0, '675', 'PG.png'),
(600, 'Asunción', 'Paraguayan', '600', 'guaraní', 'PYG', 'céntimo', 'Gs', 0, 'Republic of Paraguay', 'PY', 'PRY', 'Paraguay', '019', '005', 0, '595', 'PY.png'),
(604, 'Lima', 'Peruvian', '604', 'new sol', 'PEN', 'céntimo', 'S/.', 2, 'Republic of Peru', 'PE', 'PER', 'Peru', '019', '005', 0, '51', 'PE.png'),
(608, 'Manila', 'Filipino', '608', 'Philippine peso', 'PHP', 'centavo', 'Php', 2, 'Republic of the Philippines', 'PH', 'PHL', 'Philippines', '142', '035', 0, '63', 'PH.png'),
(612, 'Adamstown', 'Pitcairner', '612', 'New Zealand dollar', 'NZD', 'cent', '$', 2, 'Pitcairn Islands', 'PN', 'PCN', 'Pitcairn', '009', '061', 0, '649', 'PN.png'),
(616, 'Warsaw', 'Polish', '616', 'zloty', 'PLN', 'grosz (pl. groszy)', 'zł', 2, 'Republic of Poland', 'PL', 'POL', 'Poland', '150', '151', 1, '48', 'PL.png'),
(620, 'Lisbon', 'Portuguese', '620', 'euro', 'EUR', 'cent', '€', 2, 'Portuguese Republic', 'PT', 'PRT', 'Portugal', '150', '039', 1, '351', 'PT.png'),
(624, 'Bissau', 'Guinea-Bissau national', '624', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Republic of Guinea-Bissau', 'GW', 'GNB', 'Guinea-Bissau', '002', '011', 0, '245', 'GW.png'),
(626, 'Dili', 'East Timorese', '626', 'US dollar', 'USD', 'cent', '$', 2, 'Democratic Republic of East Timor', 'TL', 'TLS', 'Timor-Leste', '142', '035', 0, '670', 'TL.png'),
(630, 'San Juan', 'Puerto Rican', '630', 'US dollar', 'USD', 'cent', '$', 2, 'Commonwealth of Puerto Rico', 'PR', 'PRI', 'Puerto Rico', '019', '029', 0, '1', 'PR.png'),
(634, 'Doha', 'Qatari', '634', 'Qatari riyal', 'QAR', 'dirham', '﷼', 2, 'State of Qatar', 'QA', 'QAT', 'Qatar', '142', '145', 0, '974', 'QA.png'),
(638, 'Saint-Denis', 'Reunionese', '638', 'euro', 'EUR', 'cent', '€', 2, 'Réunion', 'RE', 'REU', 'Réunion', '002', '014', 0, '262', 'RE.png'),
(642, 'Bucharest', 'Romanian', '642', 'Romanian leu (pl. lei)', 'RON', 'ban (pl. bani)', 'lei', 2, 'Romania', 'RO', 'ROU', 'Romania', '150', '151', 1, '40', 'RO.png'),
(643, 'Moscow', 'Russian', '643', 'Russian rouble', 'RUB', 'kopek', 'руб', 2, 'Russian Federation', 'RU', 'RUS', 'Russian Federation', '150', '151', 0, '7', 'RU.png'),
(646, 'Kigali', 'Rwandan; Rwandese', '646', 'Rwandese franc', 'RWF', 'centime', 'RWF', 0, 'Republic of Rwanda', 'RW', 'RWA', 'Rwanda', '002', '014', 0, '250', 'RW.png'),
(652, 'Gustavia', 'of Saint Barthélemy', '652', 'euro', 'EUR', 'cent', NULL, NULL, 'Collectivity of Saint Barthélemy', 'BL', 'BLM', 'Saint Barthélemy', '019', '029', 0, '590', NULL),
(654, 'Jamestown', 'Saint Helenian', '654', 'Saint Helena pound', 'SHP', 'penny', '£', 2, 'Saint Helena, Ascension and Tristan da Cunha', 'SH', 'SHN', 'Saint Helena, Ascension and Tristan da Cunha', '002', '011', 0, '290', 'SH.png'),
(659, 'Basseterre', 'Kittsian; Nevisian', '659', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Federation of Saint Kitts and Nevis', 'KN', 'KNA', 'Saint Kitts and Nevis', '019', '029', 0, '1', 'KN.png'),
(660, 'The Valley', 'Anguillan', '660', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Anguilla', 'AI', 'AIA', 'Anguilla', '019', '029', 0, '1', 'AI.png'),
(662, 'Castries', 'Saint Lucian', '662', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Saint Lucia', 'LC', 'LCA', 'Saint Lucia', '019', '029', 0, '1', 'LC.png'),
(663, 'Marigot', 'of Saint Martin', '663', 'euro', 'EUR', 'cent', NULL, NULL, 'Collectivity of Saint Martin', 'MF', 'MAF', 'Saint Martin (French part)', '019', '029', 0, '590', NULL),
(666, 'Saint-Pierre', 'St-Pierrais; Miquelonnais', '666', 'euro', 'EUR', 'cent', '€', 2, 'Territorial Collectivity of Saint Pierre and Miquelon', 'PM', 'SPM', 'Saint Pierre and Miquelon', '019', '021', 0, '508', 'PM.png'),
(670, 'Kingstown', 'Vincentian', '670', 'East Caribbean dollar', 'XCD', 'cent', '$', 2, 'Saint Vincent and the Grenadines', 'VC', 'VCT', 'Saint Vincent and the Grenadines', '019', '029', 0, '1', 'VC.png'),
(674, 'San Marino', 'San Marinese', '674', 'euro', 'EUR ', 'cent', '€', 2, 'Republic of San Marino', 'SM', 'SMR', 'San Marino', '150', '039', 0, '378', 'SM.png'),
(678, 'São Tomé', 'São Toméan', '678', 'dobra', 'STD', 'centavo', 'Db', 2, 'Democratic Republic of São Tomé and Príncipe', 'ST', 'STP', 'Sao Tome and Principe', '002', '017', 0, '239', 'ST.png'),
(682, 'Riyadh', 'Saudi Arabian', '682', 'riyal', 'SAR', 'halala', '﷼', 2, 'Kingdom of Saudi Arabia', 'SA', 'SAU', 'Saudi Arabia', '142', '145', 0, '966', 'SA.png'),
(686, 'Dakar', 'Senegalese', '686', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Republic of Senegal', 'SN', 'SEN', 'Senegal', '002', '011', 0, '221', 'SN.png'),
(688, 'Belgrade', 'Serb', '688', 'Serbian dinar', 'RSD', 'para (inv.)', NULL, NULL, 'Republic of Serbia', 'RS', 'SRB', 'Serbia', '150', '039', 0, '381', NULL),
(690, 'Victoria', 'Seychellois', '690', 'Seychelles rupee', 'SCR', 'cent', '₨', 2, 'Republic of Seychelles', 'SC', 'SYC', 'Seychelles', '002', '014', 0, '248', 'SC.png'),
(694, 'Freetown', 'Sierra Leonean', '694', 'leone', 'SLL', 'cent', 'Le', 2, 'Republic of Sierra Leone', 'SL', 'SLE', 'Sierra Leone', '002', '011', 0, '232', 'SL.png'),
(702, 'Singapore', 'Singaporean', '702', 'Singapore dollar', 'SGD', 'cent', '$', 2, 'Republic of Singapore', 'SG', 'SGP', 'Singapore', '142', '035', 0, '65', 'SG.png'),
(703, 'Bratislava', 'Slovak', '703', 'euro', 'EUR', 'cent', 'Sk', 2, 'Slovak Republic', 'SK', 'SVK', 'Slovakia', '150', '151', 1, '421', 'SK.png'),
(704, 'Hanoi', 'Vietnamese', '704', 'dong', 'VND', '(10 hào', '₫', 2, 'Socialist Republic of Vietnam', 'VN', 'VNM', 'Viet Nam', '142', '035', 0, '84', 'VN.png'),
(705, 'Ljubljana', 'Slovene', '705', 'euro', 'EUR', 'cent', '€', 2, 'Republic of Slovenia', 'SI', 'SVN', 'Slovenia', '150', '039', 1, '386', 'SI.png'),
(706, 'Mogadishu', 'Somali', '706', 'Somali shilling', 'SOS', 'cent', 'S', 2, 'Somali Republic', 'SO', 'SOM', 'Somalia', '002', '014', 0, '252', 'SO.png'),
(710, 'Pretoria (ZA1)', 'South African', '710', 'rand', 'ZAR', 'cent', 'R', 2, 'Republic of South Africa', 'ZA', 'ZAF', 'South Africa', '002', '018', 0, '27', 'ZA.png'),
(716, 'Harare', 'Zimbabwean', '716', 'Zimbabwe dollar (ZW1)', 'ZWL', 'cent', 'Z$', 2, 'Republic of Zimbabwe', 'ZW', 'ZWE', 'Zimbabwe', '002', '014', 0, '263', 'ZW.png'),
(724, 'Madrid', 'Spaniard', '724', 'euro', 'EUR', 'cent', '€', 2, 'Kingdom of Spain', 'ES', 'ESP', 'Spain', '150', '039', 1, '34', 'ES.png'),
(728, 'Juba', 'South Sudanese', '728', 'South Sudanese pound', 'SSP', 'piaster', NULL, NULL, 'Republic of South Sudan', 'SS', 'SSD', 'South Sudan', '002', '015', 0, '211', NULL),
(729, 'Khartoum', 'Sudanese', '729', 'Sudanese pound', 'SDG', 'piastre', NULL, NULL, 'Republic of the Sudan', 'SD', 'SDN', 'Sudan', '002', '015', 0, '249', NULL),
(732, 'Al aaiun', 'Sahrawi', '732', 'Moroccan dirham', 'MAD', 'centime', 'MAD', 2, 'Western Sahara', 'EH', 'ESH', 'Western Sahara', '002', '015', 0, '212', 'EH.png'),
(740, 'Paramaribo', 'Surinamese', '740', 'Surinamese dollar', 'SRD', 'cent', '$', 2, 'Republic of Suriname', 'SR', 'SUR', 'Suriname', '019', '005', 0, '597', 'SR.png'),
(744, 'Longyearbyen', 'of Svalbard', '744', 'Norwegian krone (pl. kroner)', 'NOK', 'øre (inv.)', 'kr', 2, 'Svalbard and Jan Mayen', 'SJ', 'SJM', 'Svalbard and Jan Mayen', '150', '154', 0, '47', 'SJ.png'),
(748, 'Mbabane', 'Swazi', '748', 'lilangeni', 'SZL', 'cent', 'SZL', 2, 'Kingdom of Swaziland', 'SZ', 'SWZ', 'Swaziland', '002', '018', 0, '268', 'SZ.png'),
(752, 'Stockholm', 'Swedish', '752', 'krona (pl. kronor)', 'SEK', 'öre (inv.)', 'kr', 2, 'Kingdom of Sweden', 'SE', 'SWE', 'Sweden', '150', '154', 1, '46', 'SE.png'),
(756, 'Berne', 'Swiss', '756', 'Swiss franc', 'CHF', 'centime', 'CHF', 2, 'Swiss Confederation', 'CH', 'CHE', 'Switzerland', '150', '155', 0, '41', 'CH.png'),
(760, 'Damascus', 'Syrian', '760', 'Syrian pound', 'SYP', 'piastre', '£', 2, 'Syrian Arab Republic', 'SY', 'SYR', 'Syrian Arab Republic', '142', '145', 0, '963', 'SY.png'),
(762, 'Dushanbe', 'Tajik', '762', 'somoni', 'TJS', 'diram', 'TJS', 2, 'Republic of Tajikistan', 'TJ', 'TJK', 'Tajikistan', '142', '143', 0, '992', 'TJ.png'),
(764, 'Bangkok', 'Thai', '764', 'baht (inv.)', 'THB', 'satang (inv.)', '฿', 2, 'Kingdom of Thailand', 'TH', 'THA', 'Thailand', '142', '035', 0, '66', 'TH.png'),
(768, 'Lomé', 'Togolese', '768', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Togolese Republic', 'TG', 'TGO', 'Togo', '002', '011', 0, '228', 'TG.png'),
(772, '(TK2)', 'Tokelauan', '772', 'New Zealand dollar', 'NZD', 'cent', '$', 2, 'Tokelau', 'TK', 'TKL', 'Tokelau', '009', '061', 0, '690', 'TK.png'),
(776, 'Nuku’alofa', 'Tongan', '776', 'pa’anga (inv.)', 'TOP', 'seniti (inv.)', 'T$', 2, 'Kingdom of Tonga', 'TO', 'TON', 'Tonga', '009', '061', 0, '676', 'TO.png'),
(780, 'Port of Spain', 'Trinidadian; Tobagonian', '780', 'Trinidad and Tobago dollar', 'TTD', 'cent', 'TT$', 2, 'Republic of Trinidad and Tobago', 'TT', 'TTO', 'Trinidad and Tobago', '019', '029', 0, '1', 'TT.png'),
(784, 'Abu Dhabi', 'Emirian', '784', 'UAE dirham', 'AED', 'fils (inv.)', 'AED', 2, 'United Arab Emirates', 'AE', 'ARE', 'United Arab Emirates', '142', '145', 0, '971', 'AE.png'),
(788, 'Tunis', 'Tunisian', '788', 'Tunisian dinar', 'TND', 'millime', 'TND', 3, 'Republic of Tunisia', 'TN', 'TUN', 'Tunisia', '002', '015', 0, '216', 'TN.png'),
(792, 'Ankara', 'Turk', '792', 'Turkish lira (inv.)', 'TRY', 'kurus (inv.)', '₺', 2, 'Republic of Turkey', 'TR', 'TUR', 'Turkey', '142', '145', 0, '90', 'TR.png'),
(795, 'Ashgabat', 'Turkmen', '795', 'Turkmen manat (inv.)', 'TMT', 'tenge (inv.)', 'm', 2, 'Turkmenistan', 'TM', 'TKM', 'Turkmenistan', '142', '143', 0, '993', 'TM.png'),
(796, 'Cockburn Town', 'Turks and Caicos Islander', '796', 'US dollar', 'USD', 'cent', '$', 2, 'Turks and Caicos Islands', 'TC', 'TCA', 'Turks and Caicos Islands', '019', '029', 0, '1', 'TC.png'),
(798, 'Funafuti', 'Tuvaluan', '798', 'Australian dollar', 'AUD', 'cent', '$', 2, 'Tuvalu', 'TV', 'TUV', 'Tuvalu', '009', '061', 0, '688', 'TV.png'),
(800, 'Kampala', 'Ugandan', '800', 'Uganda shilling', 'UGX', 'cent', 'UGX', 0, 'Republic of Uganda', 'UG', 'UGA', 'Uganda', '002', '014', 0, '256', 'UG.png'),
(804, 'Kiev', 'Ukrainian', '804', 'hryvnia', 'UAH', 'kopiyka', '₴', 2, 'Ukraine', 'UA', 'UKR', 'Ukraine', '150', '151', 0, '380', 'UA.png'),
(807, 'Skopje', 'of the former Yugoslav Republic of Macedonia', '807', 'denar (pl. denars)', 'MKD', 'deni (inv.)', 'ден', 2, 'the former Yugoslav Republic of Macedonia', 'MK', 'MKD', 'Macedonia, the former Yugoslav Republic of', '150', '039', 0, '389', 'MK.png'),
(818, 'Cairo', 'Egyptian', '818', 'Egyptian pound', 'EGP', 'piastre', '£', 2, 'Arab Republic of Egypt', 'EG', 'EGY', 'Egypt', '002', '015', 0, '20', 'EG.png'),
(826, 'London', 'British', '826', 'pound sterling', 'GBP', 'penny (pl. pence)', '£', 2, 'United Kingdom of Great Britain and Northern Ireland', 'GB', 'GBR', 'United Kingdom', '150', '154', 1, '44', 'GB.png'),
(831, 'St Peter Port', 'of Guernsey', '831', 'Guernsey pound (GG2)', 'GGP (GG2)', 'penny (pl. pence)', NULL, NULL, 'Bailiwick of Guernsey', 'GG', 'GGY', 'Guernsey', '150', '154', 0, '44', NULL),
(832, 'St Helier', 'of Jersey', '832', 'Jersey pound (JE2)', 'JEP (JE2)', 'penny (pl. pence)', NULL, NULL, 'Bailiwick of Jersey', 'JE', 'JEY', 'Jersey', '150', '154', 0, '44', NULL),
(833, 'Douglas', 'Manxman; Manxwoman', '833', 'Manx pound (IM2)', 'IMP (IM2)', 'penny (pl. pence)', NULL, NULL, 'Isle of Man', 'IM', 'IMN', 'Isle of Man', '150', '154', 0, '44', NULL),
(834, 'Dodoma (TZ1)', 'Tanzanian', '834', 'Tanzanian shilling', 'TZS', 'cent', 'TZS', 2, 'United Republic of Tanzania', 'TZ', 'TZA', 'Tanzania, United Republic of', '002', '014', 0, '255', 'TZ.png'),
(840, 'Washington DC', 'American', '840', 'US dollar', 'USD', 'cent', '$', 2, 'United States of America', 'US', 'USA', 'United States', '019', '021', 0, '1', 'US.png'),
(850, 'Charlotte Amalie', 'US Virgin Islander', '850', 'US dollar', 'USD', 'cent', '$', 2, 'United States Virgin Islands', 'VI', 'VIR', 'Virgin Islands, U.S.', '019', '029', 0, '1', 'VI.png'),
(854, 'Ouagadougou', 'Burkinabe', '854', 'CFA franc (BCEAO)', 'XOF', 'centime', 'XOF', 0, 'Burkina Faso', 'BF', 'BFA', 'Burkina Faso', '002', '011', 0, '226', 'BF.png'),
(858, 'Montevideo', 'Uruguayan', '858', 'Uruguayan peso', 'UYU', 'centésimo', '$U', 0, 'Eastern Republic of Uruguay', 'UY', 'URY', 'Uruguay', '019', '005', 0, '598', 'UY.png'),
(860, 'Tashkent', 'Uzbek', '860', 'sum (inv.)', 'UZS', 'tiyin (inv.)', 'лв', 2, 'Republic of Uzbekistan', 'UZ', 'UZB', 'Uzbekistan', '142', '143', 0, '998', 'UZ.png'),
(862, 'Caracas', 'Venezuelan', '862', 'bolívar fuerte (pl. bolívares fuertes)', 'VEF', 'céntimo', 'Bs', 2, 'Bolivarian Republic of Venezuela', 'VE', 'VEN', 'Venezuela, Bolivarian Republic of', '019', '005', 0, '58', 'VE.png'),
(876, 'Mata-Utu', 'Wallisian; Futunan; Wallis and Futuna Islander', '876', 'CFP franc', 'XPF', 'centime', 'XPF', 0, 'Wallis and Futuna', 'WF', 'WLF', 'Wallis and Futuna', '009', '061', 0, '681', 'WF.png'),
(882, 'Apia', 'Samoan', '882', 'tala (inv.)', 'WST', 'sene (inv.)', 'WS$', 2, 'Independent State of Samoa', 'WS', 'WSM', 'Samoa', '009', '061', 0, '685', 'WS.png'),
(887, 'San’a', 'Yemenite', '887', 'Yemeni rial', 'YER', 'fils (inv.)', '﷼', 2, 'Republic of Yemen', 'YE', 'YEM', 'Yemen', '142', '145', 0, '967', 'YE.png'),
(894, 'Lusaka', 'Zambian', '894', 'Zambian kwacha (inv.)', 'ZMW', 'ngwee (inv.)', 'ZK', 2, 'Republic of Zambia', 'ZM', 'ZMB', 'Zambia', '002', '014', 0, '260', 'ZM.png');

-- --------------------------------------------------------

--
-- Table structure for table `currency_rates`
--

CREATE TABLE `currency_rates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `rate` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `currency_rates`
--

INSERT INTO `currency_rates` (`id`, `country_id`, `rate`, `created_at`, `updated_at`) VALUES
(1, 840, 1, '2021-04-21 19:52:51', '2021-04-21 19:52:51'),
(2, 566, 450, '2021-04-21 19:52:51', '2021-04-21 19:52:51');

-- --------------------------------------------------------

--
-- Table structure for table `freelancers`
--

CREATE TABLE `freelancers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `portfolio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `social_media` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skills` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `awards` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_letter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_offers`
--

CREATE TABLE `freelancer_offers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_category_id` bigint(20) UNSIGNED NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dollar',
  `timeline` int(11) NOT NULL DEFAULT '7',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_20_060423_create_contest_categories_table', 1),
(4, '2019_08_20_082322_add_slug_to_contest_categories_table', 1),
(5, '2019_08_24_095058_create_addons_table', 1),
(6, '2019_08_24_100829_create_contests_table', 1),
(7, '2019_08_24_101937_create_contest_tags_table', 1),
(8, '2019_08_24_102000_create_contest_addons_table', 1),
(9, '2019_08_24_102000_create_contest_files_table', 1),
(10, '2019_08_31_211453_create_contest_payments_table', 1),
(11, '2019_09_19_060848_add_country_id_to_users_table', 1),
(12, '2019_09_19_075204_add_avatar_to_users_table', 1),
(13, '2019_09_19_085254_create_freelancers_table', 1),
(14, '2019_09_22_123152_create_payment_methods_table', 1),
(15, '2019_09_30_042123_add_verified_to_freelancers_table', 1),
(16, '2019_10_02_060423_create_offer_categories_table', 1),
(17, '2019_10_02_062456_create_freelancer_offers_table', 1),
(18, '2019_10_07_064949_create_project_manager_offers_table', 1),
(19, '2019_10_07_070555_create_project_manager_offer_skills_table', 1),
(20, '2019_10_07_070947_create_project_manager_offer_files_table', 1),
(21, '2020_03_18_071641_add_file_name_to_project_manager_offer_files_table', 2),
(22, '2020_04_01_022526_add_banner_image_to_users_table', 3),
(23, '2020_04_01_023511_add_about_to_users_table', 3),
(24, '2020_12_25_073341_add_slug_to_contests_table', 4),
(25, '2020_12_25_112709_add_slug_to_project_manager_offers_table', 4),
(26, '2020_12_25_150840_add_icon_to_contest_categories_table', 5),
(27, '2020_12_26_073018_add_duration_to_contests_table', 6),
(28, '2020_12_26_090928_create_contest_submissions_table', 6),
(29, '2020_12_26_090948_create_contest_submission_files_table', 6),
(30, '2020_12_26_163259_add_reference_to_contest_submissions_table', 7),
(31, '2020_12_26_193211_add_position_to_contest_submissions_table', 7),
(32, '2020_12_26_193617_add_ended_at_to_contests_table', 7),
(33, '2021_03_21_201216_add_description_to_contest_submissions_table', 8),
(34, '2021_03_21_202943_create_contest_submission_file_comments_table', 9),
(35, '2021_03_27_064720_create_project_manager_offer_payments_table', 10),
(36, '2021_03_28_094941_create_project_manager_offer_interests_table', 11),
(37, '2021_03_28_123948_add_price_to_project_manager_offer_interests_table', 11),
(38, '2021_03_29_040230_add_assigned_to_project_manager_offer_interests_table', 12),
(39, '2021_03_30_105111_create_project_manager_offer_comments_table', 13),
(40, '2021_03_31_051950_add_completed_to_project_manager_offers_table', 14),
(41, '2021_04_01_195732_add_proposal_to_project_manager_offer_interests_table', 15),
(42, '2021_04_02_033127_create_contest_submission_comments_table', 16),
(43, '2021_04_03_044555_add_completed_to_contest_submissions_table', 17),
(44, '2021_04_05_191848_add_timeline_to_freelancer_offers_table', 18),
(45, '2021_04_12_063000_create_conversations_table', 19),
(46, '2021_04_12_063159_create_conversation_messages_table', 19),
(47, '2021_04_15_030158_create_withdrawals_table', 20),
(48, '2021_04_15_030924_add_reference_to_withdrawals_table', 20),
(49, '2021_04_15_031625_add_fx_rate_to_withdrawals_table', 20),
(50, '2021_04_21_181214_create_currency_rates_table', 21),
(51, '2021_04_21_190157_add_currency_to_contests_table', 21),
(52, '2021_04_21_190336_add_currency_to_freelancer_offers_table', 21),
(53, '2021_04_21_190348_add_currency_to_project_manager_offers_table', 21),
(54, '2021_04_22_033811_add_currency_to_project_manager_offer_interests_table', 22);

-- --------------------------------------------------------

--
-- Table structure for table `offer_categories`
--

CREATE TABLE `offer_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `offer_categories`
--

INSERT INTO `offer_categories` (`id`, `title`, `slug`, `created_at`, `updated_at`) VALUES
(3, 'Backend development', 'backend-development', '2020-12-27 11:49:29', '2020-12-27 11:49:29'),
(4, 'Flyer Design', 'flyer-design', '2020-12-27 11:53:06', '2020-12-27 11:53:06');

-- --------------------------------------------------------

--
-- Table structure for table `offer_sub_categories`
--

CREATE TABLE `offer_sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_amount` double NOT NULL DEFAULT '0',
  `offer_category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `offer_sub_categories`
--

INSERT INTO `offer_sub_categories` (`id`, `title`, `slug`, `base_amount`, `offer_category_id`, `created_at`, `updated_at`) VALUES
(2, 'Php', 'php', 20000, 3, '2020-12-27 11:50:59', '2020-12-27 11:50:59'),
(3, 'Python', 'python', 25000, 3, '2020-12-27 11:51:26', '2020-12-27 11:51:26'),
(4, 'e-flyer (social media, web banners)', 'e-flyer-social-media-web-banners', 10000, 4, '2020-12-27 11:54:54', '2020-12-27 11:54:54'),
(5, 'Flyer (print flyers)', 'flyer-print-flyers', 8000, 4, '2020-12-27 11:56:32', '2020-12-27 11:56:32');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank` int(10) UNSIGNED DEFAULT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `user_id`, `method`, `email`, `bank`, `account_number`, `account_name`, `created_at`, `updated_at`) VALUES
(1, 3, 'bank', NULL, 1, '0054358292', 'olufemi k', '2020-12-28 22:53:26', '2020-12-28 22:54:28'),
(2, 5, 'bank', NULL, 1, '0054358292', 'olufemi k', '2020-12-30 13:22:31', '2020-12-30 13:22:31');

-- --------------------------------------------------------

--
-- Table structure for table `project_manager_offers`
--

CREATE TABLE `project_manager_offers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sub_category_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum_designer_level` tinyint(4) DEFAULT NULL,
  `budget` double NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dollar',
  `delivery_mode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `offer_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `timeline` int(11) NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_manager_offers`
--

INSERT INTO `project_manager_offers` (`id`, `user_id`, `sub_category_id`, `title`, `slug`, `description`, `minimum_designer_level`, `budget`, `currency`, `delivery_mode`, `offer_user_id`, `timeline`, `completed`, `created_at`, `updated_at`) VALUES
(1, 4, 2, 'dsva', 'dsva', 'acas s', 0, 20000, 'dollar', 'once', NULL, 2, 0, '2021-03-27 06:42:06', '2021-03-27 06:42:06'),
(7, 4, 4, 'Some offer', 'some-offer', 'Some description for this offer', 3, 10000, 'dollar', 'once', NULL, 2, 1, '2021-03-31 04:06:43', '2021-03-31 05:29:01'),
(8, 5, 2, 'second offer test', 'second-offer-test', 'eligtvn wireowns weriowner vireg iergvbdfs jsklfvusnn fdskjnfdsb kjdgi jdsflnb jksdf gbjukldg bjgb', 0, 25000, 'dollar', 'once', NULL, 3, 1, '2021-03-31 13:42:23', '2021-03-31 14:11:34'),
(9, 5, 2, 'third offer', 'third-offer', 'lefu iker hefvk kujevu ujsiefv ujekfv', 0, 23000, 'dollar', 'continuous', NULL, 7, 0, '2021-03-31 14:14:37', '2021-03-31 14:14:37'),
(10, 10, 3, 'Supply chain Foundations', 'supply-chain-foundations', 'kfcmii daKD gvbhjcco fgwjnspoADQWUMAODWBBSFSOWEI', 0, 30000, 'dollar', 'once', NULL, 18, 0, '2021-04-25 16:21:20', '2021-04-25 16:21:20');

-- --------------------------------------------------------

--
-- Table structure for table `project_manager_offer_comments`
--

CREATE TABLE `project_manager_offer_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_manager_offer_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` enum('file','text','image') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_manager_offer_comments`
--

INSERT INTO `project_manager_offer_comments` (`id`, `project_manager_offer_id`, `user_id`, `content`, `content_type`, `created_at`, `updated_at`) VALUES
(1, 7, 2, 'Hello=....anybody here??', 'text', '2021-03-31 04:12:13', '2021-03-31 04:12:13'),
(2, 7, 4, 'Hello freelancer', 'text', '2021-03-31 04:12:24', '2021-03-31 04:12:24'),
(3, 7, 4, '[\"4angDVb3yI.jpg\"]', 'image', '2021-03-31 04:12:38', '2021-03-31 04:12:38'),
(4, 7, 2, '[\"SJTPhsxaui.jpg\"]', 'image', '2021-03-31 04:30:26', '2021-03-31 04:30:26'),
(5, 7, 2, '[\"ft9n1gmEoA.jpg\",\"9pDel1ttDF.jpg\",\"nNbyxGulhP.jpg\",\"wrMkpVgDY5.jpg\",\"kdYKkUqthQ.jpg\"]', 'file', '2021-03-31 05:05:56', '2021-03-31 05:05:56'),
(6, 8, 5, 'i want i sleek design', 'text', '2021-03-31 13:45:42', '2021-03-31 13:45:42'),
(7, 8, 5, 'as seen on the comment session', 'text', '2021-03-31 13:46:08', '2021-03-31 13:46:08'),
(8, 8, 5, '[\"TJA9C7kc8M.png\"]', 'image', '2021-03-31 13:46:36', '2021-03-31 13:46:36'),
(9, 8, 3, 'wiofu uisnofselv eofv bsfskuvrjef kugsvnj sdfukjva ufjnv kjsdfv  jsdkfnv jkdfivon dsf', 'text', '2021-03-31 14:00:54', '2021-03-31 14:00:54'),
(10, 8, 3, '[\"AAqyorHegp.jpg\"]', 'image', '2021-03-31 14:01:14', '2021-03-31 14:01:14'),
(11, 8, 3, '[\"g5pxG75W89.pdf\"]', 'file', '2021-03-31 14:08:22', '2021-03-31 14:08:22'),
(12, 10, 10, 'CNADSFTDF', 'text', '2021-04-25 16:22:44', '2021-04-25 16:22:44'),
(13, 10, 10, '[\"Hmgn85KyV8.jpg\"]', 'image', '2021-04-25 16:24:07', '2021-04-25 16:24:07');

-- --------------------------------------------------------

--
-- Table structure for table `project_manager_offer_files`
--

CREATE TABLE `project_manager_offer_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_manager_offer_id` bigint(20) UNSIGNED NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_manager_offer_files`
--

INSERT INTO `project_manager_offer_files` (`id`, `project_manager_offer_id`, `content`, `file_name`, `file_size`, `created_at`, `updated_at`) VALUES
(1, 1, 'LDeXKRHg0I.jpg', NULL, NULL, '2021-03-27 06:42:07', '2021-03-27 06:42:07'),
(2, 1, 'A48eFGr4M4.jpg', NULL, NULL, '2021-03-27 06:42:07', '2021-03-27 06:42:07'),
(3, 1, 'R4dUVSBRqp.jpg', NULL, NULL, '2021-03-27 06:42:08', '2021-03-27 06:42:08'),
(4, 7, 'bJw9M3jPLW.jpg', NULL, NULL, '2021-03-31 04:07:08', '2021-03-31 04:07:08'),
(5, 7, 'EcKme4lkO5.zip', NULL, NULL, '2021-03-31 04:07:09', '2021-03-31 04:07:09'),
(6, 8, 'yk6sDDdD3P.png', NULL, NULL, '2021-03-31 13:42:23', '2021-03-31 13:42:23'),
(7, 9, 'Q8XO8kcAMp.png', NULL, NULL, '2021-03-31 14:14:37', '2021-03-31 14:14:37');

-- --------------------------------------------------------

--
-- Table structure for table `project_manager_offer_interests`
--

CREATE TABLE `project_manager_offer_interests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_manager_offer_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dollar',
  `timeline` double NOT NULL DEFAULT '1',
  `proposal` text COLLATE utf8mb4_unicode_ci,
  `assigned` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_manager_offer_interests`
--

INSERT INTO `project_manager_offer_interests` (`id`, `project_manager_offer_id`, `user_id`, `price`, `currency`, `timeline`, `proposal`, `assigned`, `created_at`, `updated_at`) VALUES
(1, 7, 2, 2000, 'dollar', 5, NULL, 1, '2021-03-31 04:11:30', '2021-03-31 04:11:44'),
(2, 8, 3, 30000, 'dollar', 6, NULL, 1, '2021-03-31 13:55:42', '2021-03-31 13:58:28'),
(3, 9, 3, 30000, 'dollar', 5, NULL, 1, '2021-03-31 14:19:25', '2021-03-31 14:19:48'),
(4, 10, 3, 4000, 'dollar', 10, 'i am interested!', 0, '2021-04-26 08:49:39', '2021-04-26 08:49:39');

-- --------------------------------------------------------

--
-- Table structure for table `project_manager_offer_payments`
--

CREATE TABLE `project_manager_offer_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_manager_offer_id` bigint(20) UNSIGNED NOT NULL,
  `payment_reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_manager_offer_payments`
--

INSERT INTO `project_manager_offer_payments` (`id`, `project_manager_offer_id`, `payment_reference`, `payment_method`, `amount`, `paid`, `created_at`, `updated_at`) VALUES
(1, 7, '214127817', 'paystack', 10000, 1, '2021-03-31 04:07:52', '2021-03-31 04:07:52'),
(2, 8, '757965243', 'paystack', 25000, 1, '2021-03-31 13:43:06', '2021-03-31 13:43:06'),
(3, 9, '724730257', 'paystack', 23000, 1, '2021-03-31 14:14:51', '2021-03-31 14:14:51'),
(4, 10, '778828538', 'paystack', 30000, 1, '2021-04-25 16:22:27', '2021-04-25 16:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `project_manager_offer_skills`
--

CREATE TABLE `project_manager_offer_skills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_manager_offer_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_manager_offer_skills`
--

INSERT INTO `project_manager_offer_skills` (`id`, `project_manager_offer_id`, `title`, `created_at`, `updated_at`) VALUES
(1, 1, 'ac', '2021-03-27 06:42:06', '2021-03-27 06:42:06'),
(2, 7, 'dsa', '2021-03-31 04:06:43', '2021-03-31 04:06:43'),
(3, 7, 'ac', '2021-03-31 04:06:43', '2021-03-31 04:06:43'),
(4, 7, 'as', '2021-03-31 04:06:43', '2021-03-31 04:06:43'),
(5, 8, 'php', '2021-03-31 13:42:23', '2021-03-31 13:42:23'),
(6, 8, 'coding', '2021-03-31 13:42:23', '2021-03-31 13:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `freelancer` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `gender`, `first_name`, `last_name`, `username`, `email`, `email_verified_at`, `phone`, `phone_verified_at`, `password`, `active`, `freelancer`, `admin`, `remember_token`, `created_at`, `updated_at`, `country_id`, `avatar`, `banner_image`, `about`) VALUES
(1, NULL, NULL, NULL, 'admin', 'admin@email.com', '2021-04-21 19:52:51', NULL, NULL, '$2y$10$TKk/skAIEM3QBBfWWj4dS.mpKXuBfLLTYJ5IA0QyNUxpotAwK3eCa', 1, 0, 1, NULL, '2020-03-08 18:45:02', '2021-04-21 19:52:51', NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, 'one_freelancer', 'one@freelancer.com', '2020-03-08 00:00:00', NULL, NULL, '$2y$10$IUXiKVoglsNEF4xgJWH.rucTckUuR6pbdT90i4Gsv8FBlskWfNT7u', 1, 1, 0, NULL, '2020-03-08 18:45:09', '2020-03-08 18:45:09', NULL, NULL, NULL, NULL),
(3, NULL, 'Olufemi', 'Kolapo', 'Olufemi1on1', 'olufemi224@gmail.com', '2020-03-10 00:00:00', '0906 455 4919', NULL, '$2y$10$pP4JGHUIN4fNBWtN0EnwjOjtRU6JOO6P9EWBgsNhYiILFsaGefIKO', 1, 1, 0, NULL, '2020-03-10 07:19:13', '2021-04-26 09:04:59', 566, 'ie1M7KiUyX.jpg', 'F5HTikGgrG.jpg', 'ljkihugfytdrsestwretjcyvbyuiljnmionkj'),
(4, NULL, 'One', 'ProMas', 'first_pm', 'scasddskaylie.anderson@rice.biz', '2020-03-18 00:00:00', '09031863448', NULL, '$2y$10$FW6C9PjIDNX6xC2xlRPXP.eobqVgiImOiWtIM7kfbeafJHAdVsZQ.', 1, 0, 0, NULL, '2020-03-18 07:27:42', '2021-03-28 07:25:00', 840, 'Jx5SWkFgZx.jpg', 'IzHHQqCvbv.png', 'Something about me sha'),
(5, NULL, 'Kolapo', 'Kolapo', 'kolly', 'oluori1@gmail.com', '2020-12-27 00:00:00', '37258378', NULL, '$2y$10$zUPkioIjw.AK7rGkgVgyyuXLPpiYtFgP/efjDc/r4h8CQw/Zj9ZPa', 1, 0, 0, NULL, '2020-12-27 05:31:28', '2020-12-30 13:21:30', 566, 'Dyka8yQRWt.png', NULL, NULL),
(8, NULL, 'Macaulay', 'Babalola', 'babsmacheda@gmail.com', 'babsmacheda@gmail.com', '2021-05-01 00:00:00', NULL, NULL, '$2y$10$1rI1ArkgdKt/dF8CVc25aeg96o7s7oLyzPrgQVZ.zQSV9.iNafVe2', 1, 0, 0, NULL, '2021-03-21 10:36:34', '2021-03-21 10:36:34', NULL, NULL, NULL, NULL),
(9, NULL, NULL, NULL, 'Freelancer1', 'newspar001@gmail.com', '2021-03-22 00:00:00', NULL, NULL, '$2y$10$wO5Gjt6T/Ou1TB6qXaNJUOcAc2JviC8oMRtH8KyrIBIl35UIesat.', 1, 1, 0, NULL, '2021-03-22 06:11:45', '2021-03-22 06:11:45', NULL, NULL, NULL, NULL),
(10, NULL, NULL, NULL, 'vbamikole@gmail.com', 'vbamikole@gmail.com', '2021-05-01 00:00:00', NULL, NULL, '$2y$10$Lmgkl0B3KTtcT6x3MtKzf.r8rYSdfpkkEH4vAGFOQmBn4uYZjdWAS', 1, 0, 0, NULL, '2021-04-25 16:16:45', '2021-04-25 16:16:45', NULL, NULL, NULL, NULL),
(11, NULL, NULL, NULL, 'matthew.ademola@danone.com', 'vbamkidasi@gmaill.com', '2021-05-01 00:00:00', NULL, NULL, '$2y$10$9utafjuEqyXYSy4o84xqEutZWAolU3HU1LfYirTCsKy056nuVljba', 1, 1, 0, NULL, '2021-04-25 16:34:27', '2021-04-25 16:34:27', NULL, NULL, NULL, NULL),
(12, NULL, NULL, NULL, 'orikola', 'orikola1@gmail.com', '2021-05-01 00:00:00', NULL, NULL, '$2y$10$NH8IqFw6zqvv4C35trC.c.d8b5mYW8kVg/sCdIwfcyI7QlMVKcxFW', 1, 1, 0, NULL, '2021-04-27 13:04:16', '2021-04-27 13:04:16', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `fx_rate` double NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_id` int(10) UNSIGNED DEFAULT NULL,
  `account_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addons`
--
ALTER TABLE `addons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contests`
--
ALTER TABLE `contests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contests_user_id_foreign` (`user_id`),
  ADD KEY `contests_sub_category_id_foreign` (`sub_category_id`);

--
-- Indexes for table `contest_addons`
--
ALTER TABLE `contest_addons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_addons_contest_id_foreign` (`contest_id`),
  ADD KEY `contest_addons_addon_id_foreign` (`addon_id`);

--
-- Indexes for table `contest_categories`
--
ALTER TABLE `contest_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contest_categories_slug_unique` (`slug`);

--
-- Indexes for table `contest_files`
--
ALTER TABLE `contest_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_files_contest_id_foreign` (`contest_id`);

--
-- Indexes for table `contest_payments`
--
ALTER TABLE `contest_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_payments_contest_id_foreign` (`contest_id`);

--
-- Indexes for table `contest_submissions`
--
ALTER TABLE `contest_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_submissions_contest_id_foreign` (`contest_id`),
  ADD KEY `contest_submissions_user_id_foreign` (`user_id`);

--
-- Indexes for table `contest_submission_comments`
--
ALTER TABLE `contest_submission_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_submission_comments_contest_submission_id_foreign` (`contest_submission_id`),
  ADD KEY `contest_submission_comments_user_id_foreign` (`user_id`);

--
-- Indexes for table `contest_submission_files`
--
ALTER TABLE `contest_submission_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_submission_files_contest_submission_id_foreign` (`contest_submission_id`);

--
-- Indexes for table `contest_submission_file_comments`
--
ALTER TABLE `contest_submission_file_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_submission_file_comments_file_id_foreign` (`file_id`),
  ADD KEY `contest_submission_file_comments_user_id_foreign` (`user_id`);

--
-- Indexes for table `contest_sub_categories`
--
ALTER TABLE `contest_sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contest_sub_categories_slug_unique` (`slug`),
  ADD KEY `contest_sub_categories_contest_category_id_foreign` (`contest_category_id`);

--
-- Indexes for table `contest_tags`
--
ALTER TABLE `contest_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contest_tags_contest_id_foreign` (`contest_id`);

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversations_user_1_id_foreign` (`user_1_id`),
  ADD KEY `conversations_user_2_id_foreign` (`user_2_id`);

--
-- Indexes for table `conversation_messages`
--
ALTER TABLE `conversation_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversation_messages_conversation_id_foreign` (`conversation_id`),
  ADD KEY `conversation_messages_user_id_foreign` (`user_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `countries_id_index` (`id`);

--
-- Indexes for table `currency_rates`
--
ALTER TABLE `currency_rates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `currency_rates_country_id_foreign` (`country_id`);

--
-- Indexes for table `freelancers`
--
ALTER TABLE `freelancers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `freelancers_user_id_foreign` (`user_id`);

--
-- Indexes for table `freelancer_offers`
--
ALTER TABLE `freelancer_offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `freelancer_offers_user_id_foreign` (`user_id`),
  ADD KEY `freelancer_offers_sub_category_id_foreign` (`sub_category_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offer_categories`
--
ALTER TABLE `offer_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `offer_categories_slug_unique` (`slug`);

--
-- Indexes for table `offer_sub_categories`
--
ALTER TABLE `offer_sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `offer_sub_categories_slug_unique` (`slug`),
  ADD KEY `offer_sub_categories_offer_category_id_foreign` (`offer_category_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_methods_user_id_foreign` (`user_id`);

--
-- Indexes for table `project_manager_offers`
--
ALTER TABLE `project_manager_offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_manager_offers_user_id_foreign` (`user_id`),
  ADD KEY `project_manager_offers_offer_user_id_foreign` (`offer_user_id`),
  ADD KEY `project_manager_offers_sub_category_id_foreign` (`sub_category_id`);

--
-- Indexes for table `project_manager_offer_comments`
--
ALTER TABLE `project_manager_offer_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_manager_offer_comments_project_manager_offer_id_foreign` (`project_manager_offer_id`),
  ADD KEY `project_manager_offer_comments_user_id_foreign` (`user_id`);

--
-- Indexes for table `project_manager_offer_files`
--
ALTER TABLE `project_manager_offer_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_manager_offer_files_project_manager_offer_id_foreign` (`project_manager_offer_id`);

--
-- Indexes for table `project_manager_offer_interests`
--
ALTER TABLE `project_manager_offer_interests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_manager_offer_interests_project_manager_offer_id_foreign` (`project_manager_offer_id`),
  ADD KEY `project_manager_offer_interests_user_id_foreign` (`user_id`);

--
-- Indexes for table `project_manager_offer_payments`
--
ALTER TABLE `project_manager_offer_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_manager_offer_payments_project_manager_offer_id_foreign` (`project_manager_offer_id`);

--
-- Indexes for table `project_manager_offer_skills`
--
ALTER TABLE `project_manager_offer_skills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_manager_offer_skills_project_manager_offer_id_foreign` (`project_manager_offer_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `withdrawals_user_id_foreign` (`user_id`),
  ADD KEY `withdrawals_bank_id_foreign` (`bank_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addons`
--
ALTER TABLE `addons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=752;
--
-- AUTO_INCREMENT for table `contests`
--
ALTER TABLE `contests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `contest_addons`
--
ALTER TABLE `contest_addons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `contest_categories`
--
ALTER TABLE `contest_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `contest_files`
--
ALTER TABLE `contest_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `contest_payments`
--
ALTER TABLE `contest_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `contest_submissions`
--
ALTER TABLE `contest_submissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contest_submission_comments`
--
ALTER TABLE `contest_submission_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contest_submission_files`
--
ALTER TABLE `contest_submission_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contest_submission_file_comments`
--
ALTER TABLE `contest_submission_file_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contest_sub_categories`
--
ALTER TABLE `contest_sub_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `contest_tags`
--
ALTER TABLE `contest_tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `conversation_messages`
--
ALTER TABLE `conversation_messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `currency_rates`
--
ALTER TABLE `currency_rates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `freelancers`
--
ALTER TABLE `freelancers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `freelancer_offers`
--
ALTER TABLE `freelancer_offers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `offer_categories`
--
ALTER TABLE `offer_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `offer_sub_categories`
--
ALTER TABLE `offer_sub_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `project_manager_offers`
--
ALTER TABLE `project_manager_offers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `project_manager_offer_comments`
--
ALTER TABLE `project_manager_offer_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `project_manager_offer_files`
--
ALTER TABLE `project_manager_offer_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `project_manager_offer_interests`
--
ALTER TABLE `project_manager_offer_interests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `project_manager_offer_payments`
--
ALTER TABLE `project_manager_offer_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `project_manager_offer_skills`
--
ALTER TABLE `project_manager_offer_skills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `contests`
--
ALTER TABLE `contests`
  ADD CONSTRAINT `contests_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `contest_sub_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_addons`
--
ALTER TABLE `contest_addons`
  ADD CONSTRAINT `contest_addons_addon_id_foreign` FOREIGN KEY (`addon_id`) REFERENCES `addons` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contest_addons_contest_id_foreign` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_files`
--
ALTER TABLE `contest_files`
  ADD CONSTRAINT `contest_files_contest_id_foreign` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_payments`
--
ALTER TABLE `contest_payments`
  ADD CONSTRAINT `contest_payments_contest_id_foreign` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_submissions`
--
ALTER TABLE `contest_submissions`
  ADD CONSTRAINT `contest_submissions_contest_id_foreign` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contest_submissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_submission_comments`
--
ALTER TABLE `contest_submission_comments`
  ADD CONSTRAINT `contest_submission_comments_contest_submission_id_foreign` FOREIGN KEY (`contest_submission_id`) REFERENCES `contest_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contest_submission_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_submission_files`
--
ALTER TABLE `contest_submission_files`
  ADD CONSTRAINT `contest_submission_files_contest_submission_id_foreign` FOREIGN KEY (`contest_submission_id`) REFERENCES `contest_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_submission_file_comments`
--
ALTER TABLE `contest_submission_file_comments`
  ADD CONSTRAINT `contest_submission_file_comments_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `contest_submission_files` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contest_submission_file_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_sub_categories`
--
ALTER TABLE `contest_sub_categories`
  ADD CONSTRAINT `contest_sub_categories_contest_category_id_foreign` FOREIGN KEY (`contest_category_id`) REFERENCES `contest_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contest_tags`
--
ALTER TABLE `contest_tags`
  ADD CONSTRAINT `contest_tags_contest_id_foreign` FOREIGN KEY (`contest_id`) REFERENCES `contests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `conversations`
--
ALTER TABLE `conversations`
  ADD CONSTRAINT `conversations_user_1_id_foreign` FOREIGN KEY (`user_1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `conversations_user_2_id_foreign` FOREIGN KEY (`user_2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `conversation_messages`
--
ALTER TABLE `conversation_messages`
  ADD CONSTRAINT `conversation_messages_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `conversation_messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `currency_rates`
--
ALTER TABLE `currency_rates`
  ADD CONSTRAINT `currency_rates_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `freelancers`
--
ALTER TABLE `freelancers`
  ADD CONSTRAINT `freelancers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `freelancer_offers`
--
ALTER TABLE `freelancer_offers`
  ADD CONSTRAINT `freelancer_offers_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `contest_sub_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `freelancer_offers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `offer_sub_categories`
--
ALTER TABLE `offer_sub_categories`
  ADD CONSTRAINT `offer_sub_categories_offer_category_id_foreign` FOREIGN KEY (`offer_category_id`) REFERENCES `offer_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `payment_methods_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_manager_offers`
--
ALTER TABLE `project_manager_offers`
  ADD CONSTRAINT `project_manager_offers_offer_user_id_foreign` FOREIGN KEY (`offer_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_manager_offers_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `offer_sub_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_manager_offers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_manager_offer_comments`
--
ALTER TABLE `project_manager_offer_comments`
  ADD CONSTRAINT `project_manager_offer_comments_project_manager_offer_id_foreign` FOREIGN KEY (`project_manager_offer_id`) REFERENCES `project_manager_offers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_manager_offer_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_manager_offer_files`
--
ALTER TABLE `project_manager_offer_files`
  ADD CONSTRAINT `project_manager_offer_files_project_manager_offer_id_foreign` FOREIGN KEY (`project_manager_offer_id`) REFERENCES `project_manager_offers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_manager_offer_interests`
--
ALTER TABLE `project_manager_offer_interests`
  ADD CONSTRAINT `project_manager_offer_interests_project_manager_offer_id_foreign` FOREIGN KEY (`project_manager_offer_id`) REFERENCES `project_manager_offers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_manager_offer_interests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_manager_offer_payments`
--
ALTER TABLE `project_manager_offer_payments`
  ADD CONSTRAINT `project_manager_offer_payments_project_manager_offer_id_foreign` FOREIGN KEY (`project_manager_offer_id`) REFERENCES `project_manager_offers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_manager_offer_skills`
--
ALTER TABLE `project_manager_offer_skills`
  ADD CONSTRAINT `project_manager_offer_skills_project_manager_offer_id_foreign` FOREIGN KEY (`project_manager_offer_id`) REFERENCES `project_manager_offers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `withdrawals_bank_id_foreign` FOREIGN KEY (`bank_id`) REFERENCES `banks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `withdrawals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
